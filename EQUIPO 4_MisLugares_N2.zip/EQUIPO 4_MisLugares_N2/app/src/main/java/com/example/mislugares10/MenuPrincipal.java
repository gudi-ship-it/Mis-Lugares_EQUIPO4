package com.example.mislugares10;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MenuPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_principal);

        TextView titulo = findViewById(R.id.tituloMisLugares);
        Animation animGiroZoom = AnimationUtils.loadAnimation(this, R.anim.giro_con_zoom);
        titulo.startAnimation(animGiroZoom);

        Button boton1 = findViewById(R.id.btnMostrarLugares);
        Animation animAparecer = AnimationUtils.loadAnimation(this, R.anim.aparecer);
        boton1.startAnimation(animAparecer);

        Button boton2 = findViewById(R.id.btnPreferencias);
        Animation animDesplazar = AnimationUtils.loadAnimation(this, R.anim.desplazamiento_derecha);
        boton2.startAnimation(animDesplazar);

        Button botonAcerca = findViewById(R.id.btnAcercaDe);
        botonAcerca.setOnClickListener(v -> {
            Animation animGiroZoom2 = AnimationUtils.loadAnimation(this, R.anim.giro_con_zoom);
            botonAcerca.startAnimation(animGiroZoom2);

            botonAcerca.postDelayed(() -> {
                lanzarAcercaDeMejorado(null);
            }, 2000); // Espera 2 segundos para abrir la actividad
        });// ← ESTA LLAVE FALTABA

        // Configurar botones principales
        Button btnMostrarLugares = findViewById(R.id.btnMostrarLugares);
        Button btnPreferencias = findViewById(R.id.btnPreferencias);
        Button btnAcercaDe = findViewById(R.id.btnAcercaDe);
        Button btnSalir = findViewById(R.id.btnSalir);

        // Configurar botones de header
        ImageButton btnCorreo = findViewById(R.id.btnCorreo);
        ImageButton btnMenu = findViewById(R.id.btnMenu);

        // Configurar listeners de botones principales
        btnMostrarLugares.setOnClickListener(v -> {
            Intent intent = new Intent(MenuPrincipal.this, MainActivity.class);
            startActivity(intent);
        });

        btnPreferencias.setOnClickListener(v -> {
            Intent intent = new Intent(MenuPrincipal.this, Preferencias.class);
            startActivity(intent);
        });

        btnAcercaDe.setOnClickListener(v -> {
            Intent intent = new Intent(MenuPrincipal.this, AcercaDeMejorado.class);
            startActivity(intent);
        });

        btnSalir.setOnClickListener(v -> finishAffinity());

        // Configurar botón de correo
        btnCorreo.setOnClickListener(v -> compartirPorCorreo());

        // Configurar botón de menú (tres puntos)
        btnMenu.setOnClickListener(this::mostrarMenuPopup);
    }
    @Override
    protected void onResume() {
        super.onResume();
        // Si necesitas actualizar algo al volver al menú principal
    }
    public void lanzarAcercaDeMejorado(View view) {
        Intent i = new Intent(this, AcercaDeMejorado.class);
        startActivity(i);
    }

    private void compartirPorCorreo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Compartir Lugar por Correo");

        final View dialogView = getLayoutInflater().inflate(R.layout.dialogo_buscar_lugar, null);
        builder.setView(dialogView);

        final EditText etId = dialogView.findViewById(R.id.etId);
        final EditText etNombre = dialogView.findViewById(R.id.etNombre);

        builder.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idTexto = etId.getText().toString().trim();
                String nombre = etNombre.getText().toString().trim();

                long idCompartir = -1;

                if (!idTexto.isEmpty()) {
                    try {
                        idCompartir = Long.parseLong(idTexto);
                    } catch (NumberFormatException e) {
                        Toast.makeText(MenuPrincipal.this, "ID debe ser un número válido", Toast.LENGTH_LONG).show();
                        return;
                    }
                } else if (!nombre.isEmpty()) {
                    idCompartir = Lugares.buscarNombre(nombre);
                    if (idCompartir == -1) {
                        Toast.makeText(MenuPrincipal.this, "No se encontró lugar con nombre: " + nombre, Toast.LENGTH_LONG).show();
                        return;
                    }
                } else {
                    Toast.makeText(MenuPrincipal.this, "Ingresa ID o nombre del lugar", Toast.LENGTH_LONG).show();
                    return;
                }

                if (!Lugares.existeLugar((int) idCompartir)) {
                    Toast.makeText(MenuPrincipal.this, "No existe el lugar con ID: " + idCompartir, Toast.LENGTH_LONG).show();
                    return;
                }

                enviarCorreoLugar(Lugares.elemento((int) idCompartir));
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    // Nuevo método para enviar correo con información del lugar
    private void enviarCorreoLugar(Lugar lugarCompartir) {
        StringBuilder asunto = new StringBuilder();
        asunto.append("Lugar recomendado: ").append(lugarCompartir.getNombre());

        StringBuilder cuerpoCorreo = new StringBuilder();
        cuerpoCorreo.append("Te recomiendo visitar este lugar:\n\n");
        cuerpoCorreo.append("🌟 ").append(lugarCompartir.getNombre()).append("\n\n");

        if (lugarCompartir.getDireccion() != null && !lugarCompartir.getDireccion().isEmpty()) {
            cuerpoCorreo.append("📍 Dirección: ").append(lugarCompartir.getDireccion()).append("\n");
        }

        if (lugarCompartir.getPosicion() != null &&
                lugarCompartir.getPosicion().getLatitud() != 0 &&
                lugarCompartir.getPosicion().getLongitud() != 0) {

            double lat = lugarCompartir.getPosicion().getLatitud();
            double lon = lugarCompartir.getPosicion().getLongitud();
            cuerpoCorreo.append("🗺️ Ubicación: ").append(lat).append(", ").append(lon).append("\n");

            // Agregar enlace a Google Maps
            cuerpoCorreo.append("🔗 Ver en Google Maps: ")
                    .append("https://maps.google.com/?q=")
                    .append(lat).append(",").append(lon).append("\n");
        }

        if (lugarCompartir.getTelefono() != 0) {
            cuerpoCorreo.append("📞 Teléfono: ").append(lugarCompartir.getTelefono()).append("\n");
        }

        if (lugarCompartir.getUrl() != null && !lugarCompartir.getUrl().isEmpty()) {
            cuerpoCorreo.append("🌐 Sitio web: ").append(lugarCompartir.getUrl()).append("\n");
        }

        if (lugarCompartir.getComentario() != null && !lugarCompartir.getComentario().isEmpty()) {
            cuerpoCorreo.append("📝 Comentario: ").append(lugarCompartir.getComentario()).append("\n");
        }

        cuerpoCorreo.append("\n\n---\n");
        cuerpoCorreo.append("Compartido desde la aplicación Mis Lugares");

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("message/rfc822");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{""});
        intent.putExtra(Intent.EXTRA_SUBJECT, asunto.toString());
        intent.putExtra(Intent.EXTRA_TEXT, cuerpoCorreo.toString());

        try {
            startActivity(Intent.createChooser(intent, "Enviar correo..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "No hay clientes de correo instalados.", Toast.LENGTH_SHORT).show();
        }
    }

    private void mostrarMenuPopup(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.getMenuInflater().inflate(R.menu.menu_principal_popup, popup.getMenu());

        popup.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();

            if (id == R.id.menu_buscar) {
                lanzarBuscarLugar();
                return true;
            } else if (id == R.id.menu_acerca_de) {
                Intent intent = new Intent(MenuPrincipal.this, AcercaDeMejorado.class);
                startActivity(intent);
                return true;
            } else if (id == R.id.menu_preferencias) {
                Intent intent = new Intent(MenuPrincipal.this, Preferencias.class);
                startActivity(intent);
                return true;
            }
            return false;
        });

        popup.show();
    }

    private void lanzarBuscarLugar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Buscar Lugar");

        final View dialogView = getLayoutInflater().inflate(R.layout.dialogo_buscar_lugar, null);
        builder.setView(dialogView);

        final EditText etId = dialogView.findViewById(R.id.etId);
        final EditText etNombre = dialogView.findViewById(R.id.etNombre);

        builder.setPositiveButton("Buscar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idTexto = etId.getText().toString().trim();
                String nombre = etNombre.getText().toString().trim();

                long id = -1;

                if (!idTexto.isEmpty()) {
                    try {
                        id = Long.parseLong(idTexto);
                    } catch (NumberFormatException e) {
                        Toast.makeText(MenuPrincipal.this, "ID debe ser un número válido", Toast.LENGTH_LONG).show();
                        return;
                    }
                } else if (!nombre.isEmpty()) {
                    id = Lugares.buscarNombre(nombre);
                    if (id == -1) {
                        Toast.makeText(MenuPrincipal.this, "No se encontró lugar con nombre: " + nombre, Toast.LENGTH_LONG).show();
                        return;
                    }
                } else {
                    Toast.makeText(MenuPrincipal.this, "Ingresa ID o nombre del lugar", Toast.LENGTH_LONG).show();
                    return;
                }

                // Verificar si el lugar existe
                if (!Lugares.existeLugar((int) id)) {
                    Toast.makeText(MenuPrincipal.this,
                            "Error: No existe un lugar con ID " + id,
                            Toast.LENGTH_LONG).show();
                    return;
                }

                // Abrir VistaLugar con el ID especificado
                Intent i = new Intent(MenuPrincipal.this, VistaLugar.class);
                i.putExtra("id", id);
                startActivity(i);
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }
}