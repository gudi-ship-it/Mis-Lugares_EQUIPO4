package com.example.mislugares10;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.core.content.FileProvider;

import android.text.format.DateFormat;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Calendar;
import java.util.Date;

public class VistaLugarFragment extends Fragment implements TimePickerDialog.OnTimeSetListener,
        DatePickerDialog.OnDateSetListener {
    private long id;
    private Lugar lugar;
    private Uri uriFoto;

    private PackageManager getPackageManager() {
        return requireActivity().getPackageManager();
    }
    final static int RESULTADO_EDITAR = 2001;
    final static int RESULTADO_GALERIA = 2002;
    final static int RESULTADO_FOTO = 2003;

    @Override
    public View onCreateView(LayoutInflater inflador, ViewGroup contenedor,
                             Bundle savedInstanceState) {
        View vista = inflador.inflate(R.layout.vista_lugar, contenedor, false);
        setHasOptionsMenu(true);
        return vista;
    }

    @Override
    public void onActivityCreated(Bundle estado) {
        super.onActivityCreated(estado);
        Bundle extras = requireActivity().getIntent().getExtras();
        if (extras != null) {
            id = extras.getLong("id", -1);
            if (id != -1) actualizarVistas(id);
        }
    }

    public void actualizarVistas(final long id) {
        this.id = id;
        lugar = Lugares.elemento((int) id);
        if (lugar != null && getView() != null) {
            View v = getView();

            ((TextView) v.findViewById(R.id.nombre)).setText(lugar.getNombre());
            ((ImageView) v.findViewById(R.id.logo_tipo))
                    .setImageResource(lugar.getTipo().getRecurso());
            ((TextView) v.findViewById(R.id.tipo)).setText(lugar.getTipo().getTexto());
            ((TextView) v.findViewById(R.id.direccion)).setText(lugar.getDireccion());
            ((TextView) v.findViewById(R.id.telefono))
                    .setText(String.valueOf(lugar.getTelefono()));
            ((TextView) v.findViewById(R.id.url)).setText(lugar.getUrl());
            ((TextView) v.findViewById(R.id.comentario)).setText(lugar.getComentario());

            Date fecha = new Date(lugar.getFecha());
            ((TextView) v.findViewById(R.id.fecha))
                    .setText(android.text.format.DateFormat.getDateFormat(getContext()).format(fecha));
            ((TextView) v.findViewById(R.id.hora))
                    .setText(android.text.format.DateFormat.getTimeFormat(getContext()).format(fecha));

            RatingBar valoracion = v.findViewById(R.id.valoracion);
            valoracion.setOnRatingBarChangeListener(null);
            valoracion.setRating(lugar.getValoracion());
            valoracion.setOnRatingBarChangeListener((ratingBar, valor, fromUser) -> {
                if (fromUser) {
                    lugar.setValoracion(valor);
                    Lugares.actualizarLugar((int) id, lugar);
                }
            });

            ponerFoto(v.findViewById(R.id.foto), lugar.getFoto());
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflador) {
        inflador.inflate(R.menu.menu_vista_lugar, menu);
        super.onCreateOptionsMenu(menu, inflador);
    }

    public void lanzarBorrar() {
        Log.d("VistaLugarFragment", "Iniciando borrado - ID: " + id);

        new AlertDialog.Builder(requireContext())
                .setTitle("Borrado de lugar")
                .setMessage("¿Estás seguro de querer eliminar este lugar?")
                .setPositiveButton("Ok", (dialog, cualBoton) -> {
                    Log.d("VistaLugarFragment", "Confirmado borrado - ID: " + id);
                    Lugares.borrar((int) id);

                    // ESTABLECER RESULTADO PARA QUE MAINACTIVITY SEPA QUE SE BORRÓ UN LUGAR
                    requireActivity().setResult(Activity.RESULT_OK);

                    Toast.makeText(requireContext(), "Lugar eliminado correctamente", Toast.LENGTH_SHORT).show();
                    requireActivity().finish();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    public void lanzarEditarLugar() {
        Intent i = new Intent(requireActivity(), EdicionLugar.class);
        i.putExtra("id", id);
        startActivityForResult(i, RESULTADO_EDITAR);
    }

    @SuppressLint("MissingSuperCall")
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (lugar == null) return;

        if (requestCode == RESULTADO_EDITAR) {
            actualizarVistas(id);
            getView().findViewById(R.id.scrollView1).invalidate();
        } else if (requestCode == RESULTADO_FOTO && resultCode == Activity.RESULT_OK && uriFoto != null) {
            lugar.setFoto(uriFoto.toString());
            Lugares.actualizarLugar((int) id, lugar);
            ponerFoto(getView().findViewById(R.id.foto), lugar.getFoto());
        } else if (requestCode == RESULTADO_GALERIA && resultCode == Activity.RESULT_OK && data != null) {
            lugar.setFoto(data.getDataString());
            Lugares.actualizarLugar((int) id, lugar);
            ponerFoto(getView().findViewById(R.id.foto), lugar.getFoto());
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int idItem = item.getItemId();

        if (idItem == R.id.accion_compartir) {
            mostrarDialogoBuscarLugarParaCompartir();
            return true;
        } else if (idItem == R.id.accion_llegar) {
            mostrarDialogoBuscarLugarParaMapa();
            return true;
        } else if (idItem == R.id.accion_borrar) {
            lanzarBorrar();
            return true;
        } else if (idItem == R.id.accion_editar) {
            lanzarEditarLugar();
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    // NUEVO MÉTODO: Diálogo para buscar lugar para compartir
    private void mostrarDialogoBuscarLugarParaCompartir() {
        if (getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Compartir Lugar");

        final View dialogView = getLayoutInflater().inflate(R.layout.dialogo_buscar_lugar, null);
        builder.setView(dialogView);

        final EditText etId = dialogView.findViewById(R.id.etId);
        final EditText etNombre = dialogView.findViewById(R.id.etNombre);

        builder.setPositiveButton("Compartir", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idTexto = etId.getText().toString().trim();
                String nombre = etNombre.getText().toString().trim();

                long idCompartir = -1;

                if (!idTexto.isEmpty()) {
                    try {
                        idCompartir = Long.parseLong(idTexto);
                    } catch (NumberFormatException e) {
                        Toast.makeText(getContext(), "ID debe ser un número válido", Toast.LENGTH_LONG).show();
                        return;
                    }
                } else if (!nombre.isEmpty()) {
                    idCompartir = Lugares.buscarNombre(nombre);
                    if (idCompartir == -1) {
                        Toast.makeText(getContext(), "No se encontró lugar con nombre: " + nombre, Toast.LENGTH_LONG).show();
                        return;
                    }
                } else {
                    Toast.makeText(getContext(), "Ingresa ID o nombre del lugar", Toast.LENGTH_LONG).show();
                    return;
                }

                if (!Lugares.existeLugar((int) idCompartir)) {
                    Toast.makeText(getContext(), "No existe el lugar con ID: " + idCompartir, Toast.LENGTH_LONG).show();
                    return;
                }

                compartirLugar(Lugares.elemento((int) idCompartir));
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    // NUEVO MÉTODO: Diálogo para buscar lugar para mapa
    private void mostrarDialogoBuscarLugarParaMapa() {
        if (getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Cómo Llegar");

        final View dialogView = getLayoutInflater().inflate(R.layout.dialogo_buscar_lugar, null);
        builder.setView(dialogView);

        final EditText etId = dialogView.findViewById(R.id.etId);
        final EditText etNombre = dialogView.findViewById(R.id.etNombre);

        builder.setPositiveButton("Obtener Indicaciones", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idTexto = etId.getText().toString().trim();
                String nombre = etNombre.getText().toString().trim();

                long idDestino = -1;

                if (!idTexto.isEmpty()) {
                    try {
                        idDestino = Long.parseLong(idTexto);
                    } catch (NumberFormatException e) {
                        Toast.makeText(getContext(), "ID debe ser un número válido", Toast.LENGTH_LONG).show();
                        return;
                    }
                } else if (!nombre.isEmpty()) {
                    idDestino = Lugares.buscarNombre(nombre);
                    if (idDestino == -1) {
                        Toast.makeText(getContext(), "No se encontró lugar con nombre: " + nombre, Toast.LENGTH_LONG).show();
                        return;
                    }
                } else {
                    Toast.makeText(getContext(), "Ingresa ID o nombre del lugar", Toast.LENGTH_LONG).show();
                    return;
                }

                if (!Lugares.existeLugar((int) idDestino)) {
                    Toast.makeText(getContext(), "No existe el lugar con ID: " + idDestino, Toast.LENGTH_LONG).show();
                    return;
                }

                obtenerIndicacionesHaciaLugar(idDestino);
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    // Método para compartir la información del lugar
    private void compartirLugar(Lugar lugarCompartir) {
        StringBuilder textoCompartir = new StringBuilder();
        textoCompartir.append("🌟 ").append(lugarCompartir.getNombre()).append("\n\n");

        if (lugarCompartir.getDireccion() != null && !lugarCompartir.getDireccion().isEmpty()) {
            textoCompartir.append("📍 Dirección: ").append(lugarCompartir.getDireccion()).append("\n");
        }

        if (lugarCompartir.getPosicion() != null &&
                lugarCompartir.getPosicion().getLatitud() != 0 &&
                lugarCompartir.getPosicion().getLongitud() != 0) {

            double lat = lugarCompartir.getPosicion().getLatitud();
            double lon = lugarCompartir.getPosicion().getLongitud();
            textoCompartir.append("🗺️ Ubicación: ").append(lat).append(", ").append(lon).append("\n");

            // Agregar enlace a Google Maps
            textoCompartir.append("https://maps.google.com/?q=").append(lat).append(",").append(lon).append("\n");
        }

        if (lugarCompartir.getTelefono() != 0) {
            textoCompartir.append("📞 Teléfono: ").append(lugarCompartir.getTelefono()).append("\n");
        }

        if (lugarCompartir.getUrl() != null && !lugarCompartir.getUrl().isEmpty()) {
            textoCompartir.append("🌐 Web: ").append(lugarCompartir.getUrl()).append("\n");
        }

        textoCompartir.append("\nCompartido desde Mis Lugares App");

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Lugar recomendado: " + lugarCompartir.getNombre());
        intent.putExtra(Intent.EXTRA_TEXT, textoCompartir.toString());

        startActivity(Intent.createChooser(intent, "Compartir lugar"));
    }

    // Método para ser llamado desde el menú de opciones (sin parámetro View)
    public void verMapa() {
        mostrarDialogoBuscarLugarParaMapa();
    }

    // Método para ser llamado desde el XML (con parámetro View)
    public void verMapa(View view) {
        verMapa(); // Llama al método sin parámetros
    }

    // En VistaLugarFragment.java, reemplaza el método obtenerIndicacionesHaciaLugar por este:

    private void obtenerIndicacionesHaciaLugar(long idDestino) {
        Lugar lugarDestino = Lugares.elemento((int) idDestino);

        if (lugarDestino == null) {
            Toast.makeText(getContext(),
                    "Error: No existe un lugar con ID " + idDestino,
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (lugarDestino.getPosicion() == null ||
                lugarDestino.getPosicion().getLatitud() == 0 ||
                lugarDestino.getPosicion().getLongitud() == 0) {
            Toast.makeText(getContext(),
                    "Este lugar no tiene coordenadas definidas",
                    Toast.LENGTH_LONG).show();
            return;
        }

        double latDestino = lugarDestino.getPosicion().getLatitud();
        double lonDestino = lugarDestino.getPosicion().getLongitud();
        String nombre = lugarDestino.getNombre();

        // Crear URI para Google Maps en modo visualización normal
        Uri gmmIntentUri = Uri.parse("geo:" + latDestino + "," + lonDestino + "?z=15&q=" + latDestino + "," + lonDestino + "(" + Uri.encode(nombre) + ")");

        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        if (mapIntent.resolveActivity(requireActivity().getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            // Alternativa: usar la URL web de Google Maps
            Uri webIntentUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + latDestino + "," + lonDestino + "&query_place_id=" + Uri.encode(nombre));
            Intent webIntent = new Intent(Intent.ACTION_VIEW, webIntentUri);

            if (webIntent.resolveActivity(requireActivity().getPackageManager()) != null) {
                startActivity(webIntent);
            } else {
                Toast.makeText(getContext(),
                        "No hay aplicaciones de mapas instaladas",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    // Este método ya existe, lo mantenemos igual
    private void abrirMapaConDestino(Lugar lugarDestino) {
        double lat = lugarDestino.getPosicion().getLatitud();
        double lon = lugarDestino.getPosicion().getLongitud();
        String nombre = lugarDestino.getNombre();

        if (lat == 0 && lon == 0) {
            Toast.makeText(requireContext(), "Este lugar no tiene coordenadas definidas", Toast.LENGTH_LONG).show();
            return;
        }

        // Crear URI para Google Maps
        Uri gmmIntentUri = Uri.parse("geo:" + lat + "," + lon + "?z=15&q=" + lat + "," + lon + "(" + Uri.encode(nombre) + ")");

        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        // Verificar si Google Maps está disponible
        if (mapIntent.resolveActivity(requireActivity().getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            // Intentar con cualquier aplicación de mapas
            Intent fallbackIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("geo:" + lat + "," + lon + "?q=" + lat + "," + lon));

            if (fallbackIntent.resolveActivity(requireActivity().getPackageManager()) != null) {
                startActivity(fallbackIntent);
            } else {
                Toast.makeText(requireContext(), "No hay aplicaciones de mapas instaladas", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void galeria(View view) {
        try {
            // USAR ACTION_PICK para mejor compatibilidad
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");

            if (intent.resolveActivity(requireActivity().getPackageManager()) != null) {
                startActivityForResult(Intent.createChooser(intent, "Seleccionar imagen"), RESULTADO_GALERIA);
            } else {
                // Alternativa si ACTION_PICK no funciona
                Intent intentAlternativo = new Intent(Intent.ACTION_GET_CONTENT);
                intentAlternativo.setType("image/*");
                intentAlternativo.addCategory(Intent.CATEGORY_OPENABLE);

                if (intentAlternativo.resolveActivity(requireActivity().getPackageManager()) != null) {
                    startActivityForResult(Intent.createChooser(intentAlternativo, "Seleccionar imagen"), RESULTADO_GALERIA);
                } else {
                    Toast.makeText(getContext(), "No hay app de galería disponible", Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            Log.e("VistaLugarFragment", "Error al abrir galería: " + e.getMessage());
            Toast.makeText(getContext(), "Error al acceder a la galería", Toast.LENGTH_LONG).show();
        }
    }

    public void tomarFoto(View view) {
        if (getContext() == null) return;

        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

            // Crear directorio seguro
            File directorioFotos = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (directorioFotos != null && !directorioFotos.exists()) {
                directorioFotos.mkdirs();
            }

            // Nombre de archivo único
            File fotoArchivo = new File(directorioFotos,
                    "img_" + id + "_" + System.currentTimeMillis() + ".jpg");

            // Obtener URI
            uriFoto = FileProvider.getUriForFile(requireContext(),
                    requireContext().getPackageName() + ".provider",
                    fotoArchivo);

            Log.d("VistaLugarFragment", "URI de foto: " + uriFoto.toString());

            // Configurar intent
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uriFoto);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

            // Verificar disponibilidad
            if (intent.resolveActivity(requireActivity().getPackageManager()) != null) {
                startActivityForResult(intent, RESULTADO_FOTO);
            } else {
                Toast.makeText(getContext(), "No hay app de cámara disponible", Toast.LENGTH_LONG).show();
            }

        } catch (Exception e) {
            Log.e("VistaLugarFragment", "Error en tomarFoto: " + e.getMessage(), e);
            Toast.makeText(getContext(), "Error al acceder a la cámara", Toast.LENGTH_LONG).show();
        }
    }

    public void eliminarFoto(View view) {
        if (lugar == null) return;

        new AlertDialog.Builder(requireContext())
                .setTitle("Eliminación de foto")
                .setMessage("¿Estás seguro?")
                .setPositiveButton("Aceptar", (dialog, cualBoton) -> {
                    lugar.setFoto(null);
                    Lugares.actualizarLugar((int) id, lugar);

                    // CORRECCIÓN: Obtener referencia al ImageView y limpiarlo
                    ImageView fotoImageView = getView().findViewById(R.id.foto);
                    if (fotoImageView != null) {
                        fotoImageView.setImageDrawable(null); // Elimina cualquier imagen
                        // O alternativamente:
                        // fotoImageView.setImageResource(android.R.color.transparent);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    protected void ponerFoto(ImageView imageview, String uri) {
        if (uri != null && getContext() != null) {
            imageview.setImageBitmap(reduceBitmap(getContext(), uri, 1024, 1024));
        } else {
            imageview.setImageBitmap(null);
        }
    }

    public static Bitmap reduceBitmap(Context contexto, String uri, int MaxAncho, int MaxAlto){
        try {
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;

            BitmapFactory.decodeStream(contexto.getContentResolver()
                    .openInputStream(Uri.parse(uri)), null, options);

            // Calcular sample size de manera segura
            int sampleSize = 1;
            if (options.outWidth > MaxAncho || options.outHeight > MaxAlto) {
                final int mitadAncho = options.outWidth / 2;
                final int mitadAlto = options.outHeight / 2;

                while ((mitadAncho / sampleSize) >= MaxAncho &&
                        (mitadAlto / sampleSize) >= MaxAlto) {
                    sampleSize *= 2;
                }
            }

            options.inSampleSize = sampleSize;
            options.inJustDecodeBounds = false;

            Bitmap bitmap = BitmapFactory.decodeStream(contexto.getContentResolver()
                    .openInputStream(Uri.parse(uri)), null, options);

            if (bitmap == null) {
                throw new FileNotFoundException("No se pudo decodificar el bitmap");
            }

            return bitmap;

        } catch (FileNotFoundException e) {
            Log.e("reduceBitmap", "Archivo no encontrado: " + uri);
            return null;
        } catch (Exception e) {
            Log.e("reduceBitmap", "Error al procesar imagen: " + e.getMessage());
            return null;
        }
    }

    // ✅ Ahora compatible con android:onClick del XML
    public void cambiarHora(View view) {
        Toast.makeText(getContext(), "Icono hora pulsado", Toast.LENGTH_SHORT).show();
        if (lugar == null) return;

        DialogoSelectorHora dialogoHora = new DialogoSelectorHora();
        dialogoHora.setOnTimeSetListener(this);
        Bundle args = new Bundle();
        args.putLong("fecha", lugar.getFecha());
        dialogoHora.setArguments(args);
        dialogoHora.show(requireActivity().getSupportFragmentManager(), "selectorHora");
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        if (lugar == null) return;

        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(lugar.getFecha());
        cal.set(Calendar.HOUR_OF_DAY, hourOfDay);
        cal.set(Calendar.MINUTE, minute);
        lugar.setFecha(cal.getTimeInMillis());
        Lugares.actualizarLugar((int) id, lugar);
        actualizarVistas(id);
    }

    public static class DialogoSelectorHora extends DialogFragment {
        private TimePickerDialog.OnTimeSetListener escuchador;

        public void setOnTimeSetListener(TimePickerDialog.OnTimeSetListener escuchador) {
            this.escuchador = escuchador;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            Calendar calendario = Calendar.getInstance();
            Bundle args = getArguments();
            if (args != null) {
                long fecha = args.getLong("fecha");
                calendario.setTimeInMillis(fecha);
            }
            int hora = calendario.get(Calendar.HOUR_OF_DAY);
            int minuto = calendario.get(Calendar.MINUTE);
            TimePickerDialog.OnTimeSetListener listener = escuchador != null ?
                    escuchador : (v, h, m) -> {
            };
            return new TimePickerDialog(getActivity(), listener, hora, minuto,
                    android.text.format.DateFormat.is24HourFormat(getActivity()));
        }
    }

    // ✅ También actualizado para funcionar con android:onClick
    public void cambiarFecha(View view) {
        Toast.makeText(getContext(), "Icono fecha pulsado", Toast.LENGTH_SHORT).show();
        if (lugar == null) return;

        DialogoSelectorFecha dialogoFecha = new DialogoSelectorFecha();
        dialogoFecha.setOnDateListener(this);
        Bundle args = new Bundle();
        args.putLong("fecha", lugar.getFecha());
        dialogoFecha.setArguments(args);
        dialogoFecha.show(requireActivity().getSupportFragmentManager(), "selectorFecha");
    }

    @Override
    public void onDateSet(DatePicker vista, int anyo, int mes, int dia) {
        if (lugar == null) return;

        Calendar calendario = Calendar.getInstance();
        calendario.setTimeInMillis(lugar.getFecha());
        calendario.set(Calendar.YEAR, anyo);
        calendario.set(Calendar.MONTH, mes);
        calendario.set(Calendar.DAY_OF_MONTH, dia);
        lugar.setFecha(calendario.getTimeInMillis());
        Lugares.actualizarLugar((int) id, lugar);

        // Actualizar la vista de fecha
        actualizarVistas(id);
    }

    public static class DialogoSelectorFecha extends DialogFragment {

        private DatePickerDialog.OnDateSetListener escuchador;

        public void setOnDateListener(DatePickerDialog.OnDateSetListener escuchador) {
            this.escuchador = escuchador;
        }

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            Calendar calendario = Calendar.getInstance();
            Bundle args = this.getArguments();
            if (args != null) {
                long fecha = args.getLong("fecha");
                calendario.setTimeInMillis(fecha);
            }
            int anyo = calendario.get(Calendar.YEAR);
            int mes = calendario.get(Calendar.MONTH);
            int dia = calendario.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), escuchador, anyo, mes, dia);
        }
    }
}