package com.example.mislugares10;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Preferencias extends AppCompatActivity {

    private TextView tvCriterioSeleccionado;
    private TextView tvMaximoLugares;
    private Switch switchMandarNotificaciones;

    // CONSTANTES CORREGIDAS - ELIMINA LAS VIEJAS
    private static final String CRITERIO_CREACION_DESC = "Creación (Más nuevo primero)";
    private static final String CRITERIO_CREACION_ASC = "Creación (Más antiguo primero)";
    private static final String CRITERIO_VALORACION_DESC = "Valoración (Mayor a menor)";
    private static final String CRITERIO_VALORACION_ASC = "Valoración (Menor a mayor)";
    private static final String CRITERIO_DISTANCIA_ASC = "Distancia (Menor a mayor)";
    private static final String CRITERIO_DISTANCIA_DESC = "Distancia (Mayor a menor)";

    private String criterioActual = CRITERIO_CREACION_DESC; // SOLO UNA VEZ
    private int maximoLugares = 12;
    private boolean mandarNotificaciones = false;
    private SharedPreferences prefs;
    private LinearLayout layoutNotificacionesCorreo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferencias);

        // Configurar toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Habilitar botón de retroceso
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        // Inicializar SharedPreferences
        prefs = getSharedPreferences("MisPreferencias", MODE_PRIVATE);

        // Cargar preferencias guardadas - USA LA NUEVA CONSTANTE
        criterioActual = prefs.getString("criterio_ordenacion", CRITERIO_CREACION_DESC);
        maximoLugares = prefs.getInt("maximo_lugares", 12);
        mandarNotificaciones = prefs.getBoolean("mandar_notificaciones", false);

        // Referenciar vistas
        tvCriterioSeleccionado = findViewById(R.id.tvCriterioSeleccionado);
        tvMaximoLugares = findViewById(R.id.tvMaximoLugares);
        switchMandarNotificaciones = findViewById(R.id.switchMandarNotificaciones);
        LinearLayout layoutCriterio = findViewById(R.id.layoutCriterioOrdenacion);
        LinearLayout layoutMaximoLugares = findViewById(R.id.layoutMaximoLugares);
        layoutNotificacionesCorreo = findViewById(R.id.layoutNotificacionesCorreo);

        // Mostrar valores actuales
        tvCriterioSeleccionado.setText(criterioActual);
        tvMaximoLugares.setText(String.valueOf(maximoLugares));
        switchMandarNotificaciones.setChecked(mandarNotificaciones);

        // Configurar listener para "Mandar notificaciones"
        switchMandarNotificaciones.setOnCheckedChangeListener((buttonView, isChecked) -> {
            mandarNotificaciones = isChecked;
            guardarPreferenciaMandarNotificaciones(isChecked);
        });

        // Configurar click listener para el criterio de ordenación
        layoutCriterio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoCriterios();
            }
        });

        // Configurar click listener para el máximo de lugares
        layoutMaximoLugares.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mostrarDialogoMaximoLugares();
            }
        });

        // Configurar click listener para notificaciones por correo
        layoutNotificacionesCorreo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzarNotificacionesCorreo();
            }
        });
    }

    private void guardarPreferenciaMandarNotificaciones(boolean mandar) {
        mandarNotificaciones = mandar;
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("mandar_notificaciones", mandar);
        editor.apply();

        Toast.makeText(Preferencias.this,
                mandar ? "Notificaciones activadas" : "Notificaciones desactivadas",
                Toast.LENGTH_SHORT).show();
    }

    private void lanzarNotificacionesCorreo() {
        Intent intent = new Intent(Preferencias.this, NotificacionesCorreo.class);
        startActivity(intent);
    }

    private void mostrarDialogoMaximoLugares() {
        final EditText entrada = new EditText(this);
        entrada.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        entrada.setText(String.valueOf(maximoLugares));
        entrada.setSelection(entrada.getText().length());

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Máximo de lugares a mostrar");
        builder.setMessage("Limita el número de valores que se muestran en la lista");
        builder.setView(entrada);

        builder.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    int nuevoMaximo = Integer.parseInt(entrada.getText().toString());
                    if (nuevoMaximo > 0) {
                        maximoLugares = nuevoMaximo;
                        tvMaximoLugares.setText(String.valueOf(maximoLugares));
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putInt("maximo_lugares", maximoLugares);
                        editor.apply();
                        Toast.makeText(Preferencias.this,
                                "Máximo de lugares establecido en: " + maximoLugares,
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(Preferencias.this,
                                "El número debe ser mayor a 0",
                                Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(Preferencias.this,
                            "Por favor ingresa un número válido",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void mostrarDialogoCriterios() {
        // Array con las nuevas opciones
        final String[] opciones = {
                CRITERIO_CREACION_DESC,
                CRITERIO_CREACION_ASC,
                CRITERIO_VALORACION_DESC,
                CRITERIO_VALORACION_ASC,
                CRITERIO_DISTANCIA_ASC,
                CRITERIO_DISTANCIA_DESC
        };

        // Encontrar qué opción está seleccionada actualmente
        int seleccionado = 0;
        for (int i = 0; i < opciones.length; i++) {
            if (opciones[i].equals(criterioActual)) {
                seleccionado = i;
                break;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Criterio de ordenación");
        builder.setSingleChoiceItems(opciones, seleccionado, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                criterioActual = opciones[which];
                tvCriterioSeleccionado.setText(criterioActual);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("criterio_ordenacion", criterioActual);
                editor.apply();
                Toast.makeText(Preferencias.this, "Ordenación: " + criterioActual, Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // MÉTODOS ESTÁTICOS - SOLO UNA VEZ CADA UNO
    public static String getCriterioOrdenacion(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("MisPreferencias", MODE_PRIVATE);
        return prefs.getString("criterio_ordenacion", CRITERIO_CREACION_DESC);
    }

    public static int getMaximoLugares(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("MisPreferencias", MODE_PRIVATE);
        return prefs.getInt("maximo_lugares", 12);
    }

    public static boolean getMandarNotificaciones(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("MisPreferencias", MODE_PRIVATE);
        return prefs.getBoolean("mandar_notificaciones", false);
    }

    // Métodos auxiliares para verificar el tipo de criterio
    public static boolean isCriterioCreacionDesc(Context context) {
        String criterio = getCriterioOrdenacion(context);
        return criterio.equals(CRITERIO_CREACION_DESC);
    }

    public static boolean isCriterioCreacionAsc(Context context) {
        String criterio = getCriterioOrdenacion(context);
        return criterio.equals(CRITERIO_CREACION_ASC);
    }

    public static boolean isCriterioValoracionDesc(Context context) {
        String criterio = getCriterioOrdenacion(context);
        return criterio.equals(CRITERIO_VALORACION_DESC);
    }

    public static boolean isCriterioValoracionAsc(Context context) {
        String criterio = getCriterioOrdenacion(context);
        return criterio.equals(CRITERIO_VALORACION_ASC);
    }

    public static boolean isCriterioDistanciaAsc(Context context) {
        String criterio = getCriterioOrdenacion(context);
        return criterio.equals(CRITERIO_DISTANCIA_ASC);
    }

    public static boolean isCriterioDistanciaDesc(Context context) {
        String criterio = getCriterioOrdenacion(context);
        return criterio.equals(CRITERIO_DISTANCIA_DESC);
    }
}