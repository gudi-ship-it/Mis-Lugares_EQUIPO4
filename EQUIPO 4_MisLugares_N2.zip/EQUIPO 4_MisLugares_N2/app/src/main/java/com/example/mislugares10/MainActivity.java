package com.example.mislugares10;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.Toolbar;

import java.util.List;

public class MainActivity extends AppCompatActivity
        implements AdapterView.OnItemClickListener,
        LocationListener {

    // CAMBIO: Usar el nuevo AdaptadorLugaresArray
    private AdaptadorLugaresArray adaptador;
    private LocationManager manejador;
    private Location mejorLocaliz;
    private VistaLugarFragment fragmentVista;
    private static final int REQUEST_CODE_EDITAR_LUGAR = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_selector);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Lugares.inicializaDB(this);
        Lugares.setContext(this);

        // CAMBIO: Usar el nuevo adaptador con Array
        adaptador = new AdaptadorLugaresArray(this, Lugares.getListaLugares());

        // APLICAR ORDENACIÓN INICIAL
        adaptador.ordenarPorCriterio(this);

        ListView listavista = (ListView) findViewById(R.id.ListaVista);
        listavista.setAdapter(adaptador);
        listavista.setOnItemClickListener(this);
        listavista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Lugar lugar = adaptador.getItem(position);
                mostrarOpcionesLugar(lugar.getId());
                return true; // Indica que el evento fue consumido
            }
        });

        manejador = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION)==
                PackageManager.PERMISSION_GRANTED){
            if (manejador.isProviderEnabled(LocationManager.GPS_PROVIDER)){
                actualizaMejorLocaliz(manejador.getLastKnownLocation(LocationManager.GPS_PROVIDER));
            }
            if (manejador.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){
                actualizaMejorLocaliz(manejador.getLastKnownLocation(LocationManager.NETWORK_PROVIDER));
            }
        } else {
            solicitarPermisoGPS();
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.READ_EXTERNAL_STORAGE)==
                PackageManager.PERMISSION_DENIED){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 0);
        }
        fragmentVista = (VistaLugarFragment) getSupportFragmentManager()
                .findFragmentById(R.id.vista_lugar_fragment);
    }

    // NUEVO MÉTODO PARA MOSTRAR OPCIONES EN LONG CLICK
    private void mostrarOpcionesLugar(final long id) {
        final CharSequence[] opciones = {"Editar", "Borrar", "Cancelar"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Opciones del lugar");
        builder.setItems(opciones, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // Editar
                        editarLugar(id);
                        break;
                    case 1: // Borrar
                        confirmarBorrado(id);
                        break;
                    case 2: // Cancelar
                        dialog.dismiss();
                        break;
                }
            }
        });
        builder.show();
    }

    // Método para editar lugar
    private void editarLugar(long id) {
        Intent i = new Intent(MainActivity.this, EdicionLugar.class);
        i.putExtra("id", id);
        startActivityForResult(i, REQUEST_CODE_EDITAR_LUGAR);
    }

    public void solicitarPermisoGPS(){
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 0);
    }

    // CAMBIO: Ahora el id que recibimos es el ID real del lugar, no la posición
    public void onItemClick(AdapterView<?> parent, View vista, int posicion, long id){
        Lugar lugar = adaptador.getItem(posicion);
        Intent i = new Intent(this, VistaLugar.class);
        i.putExtra("id", lugar.getId()); // Usar el ID del lugar
        startActivity(i);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void lanzarAcercaDe(View view){
        Intent i = new Intent(this,AcercaDe.class);
        startActivity(i);
    }

    public void lanzarVistaLugar(View view){
        mostrarDialogoBuscarLugar("ver");
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int id = item.getItemId();

        if (id == R.id.config){
            Intent intent = new Intent(MainActivity.this, Preferencias.class);
            startActivity(intent);
            return true;
        }
        if (id == R.id.buscar){
            mostrarDialogoBuscarLugar("ver");
            return true;
        }
        if (id == R.id.about){
            lanzarAcercaDe(null);
            return true;
        }
        if (id == R.id.menu_mapa){
            abrirGoogleMapsUbicacionActual();
            return true;
        }
        if (id == R.id.accion_nuevo) {
            long id2 = Lugares.nuevo();
            Intent i = new Intent(this, EdicionLugar.class);
            i.putExtra("nuevo", true);
            i.putExtra("id", id2);
            startActivityForResult(i, REQUEST_CODE_EDITAR_LUGAR);
            return true;
        }
        if (id == R.id.accion_editar) {
            mostrarDialogoBuscarLugar("editar");
            return true;
        }
        if (id == R.id.accion_borrar) {
            mostrarDialogoBuscarLugar("borrar");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // NUEVO MÉTODO PARA BUSCAR POR ID O NOMBRE
    private void mostrarDialogoBuscarLugar(final String accion) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Buscar Lugar");

        final View dialogView = getLayoutInflater().inflate(R.layout.dialogo_buscar_lugar, null);
        builder.setView(dialogView);

        final EditText etId = dialogView.findViewById(R.id.etId);
        final EditText etNombre = dialogView.findViewById(R.id.etNombre);

        builder.setPositiveButton("Buscar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idTexto = etId.getText().toString().trim();
                String nombre = etNombre.getText().toString().trim();

                long idSeleccionado = -1;

                // Priorizar ID si se ingresó
                if (!idTexto.isEmpty()) {
                    try {
                        idSeleccionado = Long.parseLong(idTexto);
                    } catch (NumberFormatException e) {
                        Toast.makeText(MainActivity.this, "ID debe ser un número válido", Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                // Si no hay ID, buscar por nombre
                else if (!nombre.isEmpty()) {
                    idSeleccionado = Lugares.buscarNombre(nombre);
                    if (idSeleccionado == -1) {
                        Toast.makeText(MainActivity.this, "No se encontró lugar con nombre: " + nombre, Toast.LENGTH_LONG).show();
                        return;
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Ingresa ID o nombre del lugar", Toast.LENGTH_LONG).show();
                    return;
                }

                if (!Lugares.existeLugar((int) idSeleccionado)) {
                    Toast.makeText(MainActivity.this, "No existe el lugar con ID: " + idSeleccionado, Toast.LENGTH_LONG).show();
                    return;
                }

                ejecutarAccion(accion, idSeleccionado);
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    private void ejecutarAccion(String accion, long id) {
        switch (accion) {
            case "ver":
                Intent i = new Intent(MainActivity.this, VistaLugar.class);
                i.putExtra("id", id);
                startActivity(i);
                break;
            case "editar":
                Intent intentEditar = new Intent(MainActivity.this, EdicionLugar.class);
                intentEditar.putExtra("id", id);
                startActivityForResult(intentEditar, REQUEST_CODE_EDITAR_LUGAR);
                break;
            case "borrar":
                confirmarBorrado(id);
                break;
        }
    }

    private void abrirGoogleMapsUbicacionActual() {
        try {
            if (Lugares.posicionActual == null ||
                    Lugares.posicionActual.getLatitud() == 0 ||
                    Lugares.posicionActual.getLongitud() == 0) {
                Toast.makeText(this, "Ubicación no disponible. Esperando GPS...", Toast.LENGTH_LONG).show();
                return;
            }

            double lat = Lugares.posicionActual.getLatitud();
            double lon = Lugares.posicionActual.getLongitud();

            Uri gmmIntentUri = Uri.parse("geo:" + lat + "," + lon + "?z=15&q=" + lat + "," + lon + "(Mi+ubicación)");
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");

            if (mapIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapIntent);
            } else {
                Intent fallbackIntent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("geo:" + lat + "," + lon + "?q=" + lat + "," + lon));
                if (fallbackIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(fallbackIntent);
                } else {
                    Toast.makeText(this, "No hay aplicaciones de mapas instaladas", Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            Log.e("MainActivity", "Error al abrir Google Maps: " + e.getMessage());
            Toast.makeText(this, "Error al abrir Google Maps", Toast.LENGTH_SHORT).show();
        }
    }

    // NUEVO MÉTODO PARA CONFIRMAR BORRADO
    private void confirmarBorrado(final long id) {
        Lugar lugar = Lugares.elemento((int) id);
        String nombreLugar = (lugar != null && lugar.getNombre() != null) ?
                lugar.getNombre() : "este lugar";

        new AlertDialog.Builder(this)
                .setTitle("Confirmar Borrado")
                .setMessage("¿Estás seguro de que quieres borrar \"" + nombreLugar + "\"?")
                .setPositiveButton("Sí, borrar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int whichButton) {
                        Lugares.borrar((int) id);
                        Toast.makeText(MainActivity.this, "Lugar borrado exitosamente", Toast.LENGTH_SHORT).show();
                        actualizaLista(); // Actualizar la lista después de borrar
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        activarProveedores();
        // ACTUALIZAR LA LISTA CON EL ORDEN CORRECTO
        actualizaLista();
    }

    private void activarProveedores(){
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        if (manejador.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            manejador.requestLocationUpdates(LocationManager.GPS_PROVIDER, 20 * 1000, 5, this);
        }
        if (manejador.isProviderEnabled(LocationManager.NETWORK_PROVIDER)){
            manejador.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10 * 1000, 10, this);
        }
    }

    @Override
    protected void onPause(){
        super.onPause();
        manejador.removeUpdates(this);
    }

    @Override
    public void onLocationChanged(Location location){
        Log.d(Lugares.TAG, "Nueva Localizacion: " + location);
        actualizaMejorLocaliz(location);

        // ACTUALIZAR ORDENACIÓN SI ES POR DISTANCIA
        if (Preferencias.isCriterioDistanciaAsc(this) || Preferencias.isCriterioDistanciaDesc(this)) {
            adaptador.ordenarPorCriterio(this);
        }
    }

    @Override
    public void onProviderDisabled(String proveedor){
        Log.d(Lugares.TAG,"Se deshabilita: " + proveedor);
        activarProveedores();
    }

    @Override
    public void onProviderEnabled(String proveedor){
        Log.d(Lugares.TAG,"Se habilita: " + proveedor);
        activarProveedores();
    }

    @Override
    public void onStatusChanged(String proveedor, int estado, Bundle extras){
        Log.d(Lugares.TAG,"Cambia estado: " + proveedor);
        activarProveedores();
    }

    private static final long DOS_MINUTOS = 2 * 60 * 1000;

    private void actualizaMejorLocaliz(Location localiz){
        if(localiz != null && (mejorLocaliz == null
                || localiz.getAccuracy() < 2 * mejorLocaliz.getAccuracy()
                || localiz.getTime() - mejorLocaliz.getTime() > DOS_MINUTOS)) {
            Log.d(Lugares.TAG,"Nueva mejor ubicacion");
            mejorLocaliz = localiz;
            Lugares.posicionActual.setLatitud(localiz.getLatitude());
            Lugares.posicionActual.setLongitud(localiz.getLongitude());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("MainActivity", "onActivityResult - requestCode: " + requestCode + ", resultCode: " + resultCode);

        if (resultCode == Activity.RESULT_OK) {
            Log.d("MainActivity", "Operación completada - actualizando lista");
            actualizaLista();
            Toast.makeText(this, "Cambios aplicados correctamente", Toast.LENGTH_SHORT).show();
        }
    }

    // CAMBIO: Actualizar la lista recargando desde BD y reordenando
    public void actualizaLista() {
        try {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // Recargar datos desde BD
                    Lugares.cargarLugaresDesdeBD();

                    // Actualizar el adaptador
                    adaptador.clear();
                    adaptador.addAll(Lugares.getListaLugares());

                    // Aplicar ordenación
                    adaptador.ordenarPorCriterio(MainActivity.this);

                    adaptador.notifyDataSetChanged();

                    Log.d("MainActivity", "Lista actualizada exitosamente - " + adaptador.getCount() + " lugares");
                }
            });
        } catch (Exception e) {
            Log.e("MainActivity", "Error al actualizar lista: " + e.getMessage());
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "Error al actualizar la lista", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public void muestraLugar(long id){
        if (fragmentVista != null){
            fragmentVista.actualizarVistas(id);
        } else {
            Intent intento = new Intent(this, VistaLugar.class);
            intento.putExtra("id", id);
            startActivityForResult(intento, 0);
        }
    }
}