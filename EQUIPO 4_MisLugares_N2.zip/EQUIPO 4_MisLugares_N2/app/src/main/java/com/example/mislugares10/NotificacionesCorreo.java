package com.example.mislugares10;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NotificacionesCorreo extends AppCompatActivity {

    private ListView listViewPreferences;
    private PreferenceAdapter adapter;
    private List<PreferenceItem> preferenceItems;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notificaciones_correo);

        // Configurar toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle("Notificaciones por correo");
        }

        // Inicializar SharedPreferences
        prefs = getSharedPreferences("NotificacionesCorreo", MODE_PRIVATE);

        initPreferenceItems();
        setupListView();
    }

    private void initPreferenceItems() {
        preferenceItems = new ArrayList<>();

        // Cargar valores guardados
        boolean recibirCorreos = prefs.getBoolean("recibir_correos", false);
        String direccionCorreo = prefs.getString("direccion_correo", "");
        Set<String> tiposNotificaciones = prefs.getStringSet("tipos_notificaciones", new HashSet<String>());

        preferenceItems.add(new PreferenceItem(
                "recibir_correos",
                "Recibir correos",
                "Recibir correos con información comercial",
                PreferenceItem.TYPE_SWITCH,
                recibirCorreos
        ));

        preferenceItems.add(new PreferenceItem(
                "direccion_correo",
                "Dirección de correo",
                direccionCorreo.isEmpty() ? "Cuenta donde se mandarán las notificaciones" : direccionCorreo,
                PreferenceItem.TYPE_NORMAL,
                false
        ));

        preferenceItems.add(new PreferenceItem(
                "tipos_notificaciones",
                "Tipos de notificaciones",
                generarResumenTiposNotificaciones(tiposNotificaciones),
                PreferenceItem.TYPE_NORMAL,
                false
        ));
    }

    private String generarResumenTiposNotificaciones(Set<String> tipos) {
        if (tipos == null || tipos.isEmpty()) {
            return "Tipos de correos que se reciben";
        }

        StringBuilder resumen = new StringBuilder();
        for (String tipo : tipos) {
            if (resumen.length() > 0) {
                resumen.append(", ");
            }
            resumen.append(tipo);
        }
        return resumen.toString();
    }

    private void setupListView() {
        listViewPreferences = findViewById(R.id.listViewPreferences);
        adapter = new PreferenceAdapter();
        listViewPreferences.setAdapter(adapter);

        listViewPreferences.setOnItemClickListener((parent, view, position, id) -> {
            PreferenceItem item = preferenceItems.get(position);
            onPreferenceClick(item);
        });
    }

    private void onPreferenceClick(PreferenceItem item) {
        switch (item.getKey()) {
            case "direccion_correo":
                mostrarDialogoDireccionCorreo();
                break;
            case "tipos_notificaciones":
                mostrarDialogoTiposNotificaciones();
                break;
            // "recibir_correos" es un switch, se maneja automáticamente
        }
    }

    private void mostrarDialogoDireccionCorreo() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Dirección de correo");

        // Obtener el correo actual guardado
        String correoActual = prefs.getString("direccion_correo", "");

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        input.setText(correoActual);
        input.setSelection(input.getText().length());

        builder.setView(input);
        builder.setMessage("Ingresa tu dirección de correo electrónico:");

        builder.setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String nuevoCorreo = input.getText().toString().trim();

                if (isValidEmail(nuevoCorreo)) {
                    // Guardar en SharedPreferences
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("direccion_correo", nuevoCorreo);
                    editor.apply();

                    // Actualizar el item en la lista
                    for (PreferenceItem item : preferenceItems) {
                        if (item.getKey().equals("direccion_correo")) {
                            item.setSummary(nuevoCorreo);
                            break;
                        }
                    }

                    adapter.notifyDataSetChanged();
                    Toast.makeText(NotificacionesCorreo.this,
                            "Correo guardado correctamente", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(NotificacionesCorreo.this,
                            "Por favor ingresa un correo válido", Toast.LENGTH_LONG).show();
                }
            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        String emailPattern = "[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}";
        return email.matches(emailPattern);
    }

    private void mostrarDialogoTiposNotificaciones() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Tipos de notificaciones");

        // Obtener selecciones actuales
        Set<String> seleccionesActuales = prefs.getStringSet("tipos_notificaciones", new HashSet<String>());

        // Opciones disponibles
        final String[] opciones = {
                "Nuevos lugares agregados",
                "Ofertas especiales",
                "Recordatorios de visitas",
                "Lugares populares cerca",
                "Actualizaciones de la aplicación",
                "Encuestas y opiniones"
        };

        // Convertir Set a array booleano para las selecciones
        final boolean[] selecciones = new boolean[opciones.length];
        for (int i = 0; i < opciones.length; i++) {
            selecciones[i] = seleccionesActuales.contains(opciones[i]);
        }

        builder.setMultiChoiceItems(opciones, selecciones, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                selecciones[which] = isChecked;
            }
        });

        builder.setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Set<String> nuevasSelecciones = new HashSet<>();
                for (int i = 0; i < opciones.length; i++) {
                    if (selecciones[i]) {
                        nuevasSelecciones.add(opciones[i]);
                    }
                }

                // Guardar en SharedPreferences
                SharedPreferences.Editor editor = prefs.edit();
                editor.putStringSet("tipos_notificaciones", nuevasSelecciones);
                editor.apply();

                // Actualizar el item en la lista
                for (PreferenceItem item : preferenceItems) {
                    if (item.getKey().equals("tipos_notificaciones")) {
                        item.setSummary(generarResumenTiposNotificaciones(nuevasSelecciones));
                        break;
                    }
                }

                adapter.notifyDataSetChanged();

                String mensaje = nuevasSelecciones.isEmpty() ?
                        "No se recibirán notificaciones" :
                        "Tipos de notificación guardados: " + nuevasSelecciones.size();
                Toast.makeText(NotificacionesCorreo.this, mensaje, Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.setNeutralButton("Seleccionar todos", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Seleccionar todas las opciones
                for (int i = 0; i < selecciones.length; i++) {
                    selecciones[i] = true;
                }
                // Actualizar el diálogo
                ListView listView = ((AlertDialog) dialog).getListView();
                if (listView != null) {
                    for (int i = 0; i < listView.getCount(); i++) {
                        listView.setItemChecked(i, true);
                    }
                }
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    // Clase para representar cada item de preferencia
    private static class PreferenceItem {
        public static final int TYPE_NORMAL = 0;
        public static final int TYPE_SWITCH = 1;

        private String key;
        private String title;
        private String summary;
        private int type;
        private boolean switchValue;

        public PreferenceItem(String key, String title, String summary, int type, boolean switchValue) {
            this.key = key;
            this.title = title;
            this.summary = summary;
            this.type = type;
            this.switchValue = switchValue;
        }

        // Getters y setters
        public String getKey() { return key; }
        public String getTitle() { return title; }
        public String getSummary() { return summary; }
        public void setSummary(String summary) { this.summary = summary; }
        public int getType() { return type; }
        public boolean isSwitchValue() { return switchValue; }
        public void setSwitchValue(boolean value) { this.switchValue = value; }
    }

    // Adapter para la lista de preferencias
    private class PreferenceAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return preferenceItems.size();
        }

        @Override
        public Object getItem(int position) {
            return preferenceItems.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public int getViewTypeCount() {
            return 2; // Dos tipos: normal y switch
        }

        @Override
        public int getItemViewType(int position) {
            return preferenceItems.get(position).getType();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            PreferenceItem item = preferenceItems.get(position);

            if (item.getType() == PreferenceItem.TYPE_SWITCH) {
                return createSwitchView(item, convertView, parent);
            } else {
                return createNormalView(item, convertView, parent);
            }
        }

        private View createNormalView(PreferenceItem item, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_preference, parent, false);
            }

            TextView title = convertView.findViewById(R.id.title);
            TextView summary = convertView.findViewById(R.id.summary);

            title.setText(item.getTitle());
            summary.setText(item.getSummary());

            return convertView;
        }

        private View createSwitchView(PreferenceItem item, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_preference_switch, parent, false);
            }

            TextView title = convertView.findViewById(R.id.title);
            TextView summary = convertView.findViewById(R.id.summary);
            Switch switchWidget = convertView.findViewById(R.id.switchWidget);

            title.setText(item.getTitle());
            summary.setText(item.getSummary());
            switchWidget.setChecked(item.isSwitchValue());

            // El switch maneja su propio estado
            switchWidget.setOnCheckedChangeListener((buttonView, isChecked) -> {
                item.setSwitchValue(isChecked);
                guardarPreferenciaRecibirCorreos(isChecked);
            });

            return convertView;
        }

        private void guardarPreferenciaRecibirCorreos(boolean recibir) {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("recibir_correos", recibir);
            editor.apply();

            Toast.makeText(NotificacionesCorreo.this,
                    recibir ? "Recibir correos activado" : "Recibir correos desactivado",
                    Toast.LENGTH_SHORT).show();
        }
    }
}