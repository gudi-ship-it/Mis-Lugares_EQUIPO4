package com.example.mislugares10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AdaptadorLugaresArray extends ArrayAdapter<Lugar> {

    private LayoutInflater inflador;
    private List<Lugar> listaLugares;

    public AdaptadorLugaresArray(Context contexto, List<Lugar> lugares) {
        super(contexto, R.layout.elemento_lista, lugares);
        this.listaLugares = lugares;
        inflador = (LayoutInflater) contexto.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int posicion, View vistaReciclada, ViewGroup padre) {
        ViewHolder holder;

        if (vistaReciclada == null) {
            vistaReciclada = inflador.inflate(R.layout.elemento_lista, padre, false);
            holder = new ViewHolder();
            holder.nombre = vistaReciclada.findViewById(R.id.nombre);
            holder.direccion = vistaReciclada.findViewById(R.id.direccion);
            holder.foto = vistaReciclada.findViewById(R.id.foto);
            holder.valoracion = vistaReciclada.findViewById(R.id.valoracion);
            holder.distancia = vistaReciclada.findViewById(R.id.distancia);
            holder.idLugar = vistaReciclada.findViewById(R.id.id_lugar);
            vistaReciclada.setTag(holder);
        } else {
            holder = (ViewHolder) vistaReciclada.getTag();
        }

        Lugar lugar = getItem(posicion);

        // Establecer los valores en las vistas
        holder.nombre.setText(lugar.getNombre());
        holder.direccion.setText(lugar.getDireccion());

        // Mostrar ID del lugar
        if (holder.idLugar != null) {
            holder.idLugar.setText("ID: " + lugar.getId());
        }

        // Configurar la imagen según el tipo de lugar
        holder.foto.setImageResource(lugar.getTipo().getRecurso());
        holder.foto.setScaleType(ImageView.ScaleType.FIT_END);

        // Configurar la valoración
        holder.valoracion.setRating(lugar.getValoracion());

        // Calcular y mostrar la distancia
        if (Lugares.posicionActual != null && lugar.getPosicion() != null
                && lugar.getPosicion().getLatitud() != 0) {
            int d = (int) Lugares.posicionActual.distancia(lugar.getPosicion());
            if (d < 2000) {
                holder.distancia.setText(d + " m");
            } else {
                holder.distancia.setText((d/1000) + " km");
            }
        } else {
            holder.distancia.setText("--");
        }

        return vistaReciclada;
    }

    // Método para ordenar por diferentes criterios
    public void ordenarPorCriterio(Context contexto) {
        if (listaLugares == null || listaLugares.isEmpty()) return;

        if (Preferencias.isCriterioCreacionDesc(contexto)) {
            Collections.sort(listaLugares, new Comparator<Lugar>() {
                @Override
                public int compare(Lugar l1, Lugar l2) {
                    return Long.compare(l2.getFecha(), l1.getFecha()); // Más nuevo primero
                }
            });
        } else if (Preferencias.isCriterioCreacionAsc(contexto)) {
            Collections.sort(listaLugares, new Comparator<Lugar>() {
                @Override
                public int compare(Lugar l1, Lugar l2) {
                    return Long.compare(l1.getFecha(), l2.getFecha()); // Más antiguo primero
                }
            });
        } else if (Preferencias.isCriterioValoracionDesc(contexto)) {
            Collections.sort(listaLugares, new Comparator<Lugar>() {
                @Override
                public int compare(Lugar l1, Lugar l2) {
                    return Float.compare(l2.getValoracion(), l1.getValoracion()); // Mayor a menor
                }
            });
        } else if (Preferencias.isCriterioValoracionAsc(contexto)) {
            Collections.sort(listaLugares, new Comparator<Lugar>() {
                @Override
                public int compare(Lugar l1, Lugar l2) {
                    return Float.compare(l1.getValoracion(), l2.getValoracion()); // Menor a mayor
                }
            });
        } else if (Preferencias.isCriterioDistanciaAsc(contexto)) {
            // Ordenar por distancia (menor a mayor)
            Collections.sort(listaLugares, new Comparator<Lugar>() {
                @Override
                public int compare(Lugar l1, Lugar l2) {
                    double d1 = calcularDistancia(l1);
                    double d2 = calcularDistancia(l2);
                    return Double.compare(d1, d2);
                }
            });
        } else if (Preferencias.isCriterioDistanciaDesc(contexto)) {
            // Ordenar por distancia (mayor a menor)
            Collections.sort(listaLugares, new Comparator<Lugar>() {
                @Override
                public int compare(Lugar l1, Lugar l2) {
                    double d1 = calcularDistancia(l1);
                    double d2 = calcularDistancia(l2);
                    return Double.compare(d2, d1);
                }
            });
        }

        notifyDataSetChanged();
    }

    private double calcularDistancia(Lugar lugar) {
        if (Lugares.posicionActual != null && lugar.getPosicion() != null
                && lugar.getPosicion().getLatitud() != 0) {
            return Lugares.posicionActual.distancia(lugar.getPosicion());
        }
        return Double.MAX_VALUE; // Si no hay posición, poner al final
    }

    // ViewHolder para mejor rendimiento
    static class ViewHolder {
        TextView nombre;
        TextView direccion;
        ImageView foto;
        RatingBar valoracion;
        TextView distancia;
        TextView idLugar;
    }
}