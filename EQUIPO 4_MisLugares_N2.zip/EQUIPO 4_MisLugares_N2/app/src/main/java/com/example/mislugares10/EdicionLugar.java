package com.example.mislugares10;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class EdicionLugar extends AppCompatActivity {
    private long id;
    private Lugar lugar;
    private EditText nombre;
    private Spinner tipo;
    private EditText direccion;
    private EditText telefono;
    private EditText url;
    private EditText comentario;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstancestate){
        super.onCreate(savedInstancestate);
        setContentView(R.layout.edicion_lugar);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Verificar que hay extras
        Bundle extras = getIntent().getExtras();
        if (extras == null) {
            Log.e("EdicionLugar", "No se recibieron extras en el Intent");
            Toast.makeText(this, "Error: No se recibieron datos del lugar", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Obtener ID y verificar que es válido
        id = extras.getLong("id", -1);
        if (id == -1) {
            Log.e("EdicionLugar", "ID inválido recibido: " + id);
            Toast.makeText(this, "Error: ID de lugar inválido", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Obtener el lugar y verificar que existe
        lugar = Lugares.elemento((int) id);
        if (lugar == null) {
            Log.e("EdicionLugar", "No se pudo cargar el lugar con ID: " + id);
            Toast.makeText(this, "Error: No se encontró el lugar", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        Log.d("EdicionLugar", "Editando lugar - ID: " + id + ", Nombre: " + lugar.getNombre());

        try {
            // Inicializar vistas
            nombre = findViewById(R.id.etNombre);
            direccion = findViewById(R.id.etDireccion);
            telefono = findViewById(R.id.etTelefono);
            url = findViewById(R.id.etUrl);
            comentario = findViewById(R.id.etComentario);
            tipo = findViewById(R.id.spinnerTipo);

            // Verificar que las vistas no son nulas
            if (nombre == null || direccion == null || telefono == null ||
                    url == null || comentario == null || tipo == null) {
                Log.e("EdicionLugar", "Una o más vistas son nulas");
                Toast.makeText(this, "Error: Problema con la interfaz", Toast.LENGTH_LONG).show();
                finish();
                return;
            }

            // Configurar valores en las vistas
            nombre.setText(lugar.getNombre() != null ? lugar.getNombre() : "");
            direccion.setText(lugar.getDireccion() != null ? lugar.getDireccion() : "");
            telefono.setText(Integer.toString(lugar.getTelefono()));
            url.setText(lugar.getUrl() != null ? lugar.getUrl() : "");
            comentario.setText(lugar.getComentario() != null ? lugar.getComentario() : "");

            // Configurar spinner de tipos
            ArrayAdapter<String> adaptador = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_spinner_item,
                    TipoLugar.getNombre());

            adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            tipo.setAdapter(adaptador);

            // Seleccionar el tipo actual del lugar
            if (lugar.getTipo() != null) {
                tipo.setSelection(lugar.getTipo().ordinal());
            } else {
                tipo.setSelection(0); // Valor por defecto
                Log.w("EdicionLugar", "Tipo de lugar es nulo, usando valor por defecto");
            }

            // Añadir listener para geocodificación automática cuando se cambia la dirección
            direccion.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus) {
                        // Cuando el campo de dirección pierde el foco, intentar geocodificar
                        String direccionTexto = direccion.getText().toString().trim();
                        if (!direccionTexto.isEmpty() &&
                                (lugar.getPosicion().getLatitud() == 0 || lugar.getPosicion().getLongitud() == 0)) {
                            geocodificarDireccion(direccionTexto);
                        }
                    }
                }
            });

            Log.d("EdicionLugar", "Vistas inicializadas correctamente");

        } catch (Exception e) {
            Log.e("EdicionLugar", "Error crítico en onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error crítico al cargar la edición", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    // Método para geocodificar la dirección
    private void geocodificarDireccion(String direccion) {
        if (!Geocoder.isPresent()) {
            Toast.makeText(this, "El servicio de geocodificación no está disponible", Toast.LENGTH_SHORT).show();
            return;
        }

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Obteniendo ubicación...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        new GeocodingTask().execute(direccion);
    }

    public void onGeocodificarClick(View view) {
        String direccionTexto = direccion.getText().toString().trim();
        if (!direccionTexto.isEmpty()) {
            geocodificarDireccion(direccionTexto);
        } else {
            Toast.makeText(this, "Ingresa una dirección primero", Toast.LENGTH_SHORT).show();
        }
    }

    // AsyncTask para geocodificación en segundo plano
    @SuppressLint("StaticFieldLeak")
    private class GeocodingTask extends AsyncTask<String, Void, GeoPunto> {
        private String errorMessage = "";

        @Override
        protected GeoPunto doInBackground(String... direcciones) {
            String direccion = direcciones[0];
            Geocoder geocoder = new Geocoder(EdicionLugar.this, Locale.getDefault());

            try {
                List<Address> addresses = geocoder.getFromLocationName(direccion, 1);
                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    double latitud = address.getLatitude();
                    double longitud = address.getLongitude();

                    Log.d("Geocoding", "Dirección encontrada: " + latitud + ", " + longitud);
                    return new GeoPunto(latitud, longitud);
                } else {
                    errorMessage = "No se encontró la dirección";
                }
            } catch (IOException e) {
                errorMessage = "Error de conexión: " + e.getMessage();
                Log.e("Geocoding", "Error en geocodificación: " + e.getMessage());
            } catch (Exception e) {
                errorMessage = "Error inesperado: " + e.getMessage();
                Log.e("Geocoding", "Error inesperado: " + e.getMessage());
            }

            return null;
        }

        @Override
        protected void onPostExecute(GeoPunto resultado) {
            progressDialog.dismiss();

            if (resultado != null) {
                // Actualizar la posición del lugar
                lugar.setPosicion(resultado);
                Toast.makeText(EdicionLugar.this,
                        "Ubicación actualizada: " + resultado.getLatitud() + ", " + resultado.getLongitud(),
                        Toast.LENGTH_LONG).show();
                Log.d("Geocoding", "Geocodificación exitosa para: " + direccion.getText().toString());
            } else {
                Toast.makeText(EdicionLugar.this,
                        "No se pudo obtener la ubicación: " + errorMessage,
                        Toast.LENGTH_LONG).show();
                Log.e("Geocoding", "Geocodificación fallida: " + errorMessage);
            }
        }
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_edicion_lugar, menu);

        // Añadir opción para geocodificación manual
        MenuItem item = menu.add(Menu.NONE, R.id.accion_geocodificar, Menu.NONE, "Obtener ubicación");
        item.setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);

        return true;
    }

    // En EdicionLugar.java, modifica el método guardar():

    public void guardar(){
        try {
            // Validar campos obligatorios
            if (nombre.getText().toString().trim().isEmpty()) {
                Toast.makeText(this, "El nombre es obligatorio", Toast.LENGTH_SHORT).show();
                return;
            }

            // Si no hay coordenadas y hay dirección, intentar geocodificar una última vez
            String direccionTexto = direccion.getText().toString().trim();
            if (!direccionTexto.isEmpty() &&
                    (lugar.getPosicion() == null || lugar.getPosicion().getLatitud() == 0 || lugar.getPosicion().getLongitud() == 0)) {

                Toast.makeText(this, "Obteniendo ubicación antes de guardar...", Toast.LENGTH_SHORT).show();
                geocodificarDireccion(direccionTexto);

                // Esperar un momento para que la geocodificación se complete
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }

            // Actualizar el objeto lugar con los nuevos valores
            lugar.setNombre(nombre.getText().toString());
            lugar.setTipo(TipoLugar.values()[tipo.getSelectedItemPosition()]);
            lugar.setDireccion(direccionTexto);

            // MANEJAR EL TELÉFONO DE FORMA MEJORADA
            String telefonoTexto = telefono.getText().toString().trim();
            if (!telefonoTexto.isEmpty()) {
                try {
                    // Limpiar el texto del teléfono (remover espacios, guiones, etc.)
                    String telefonoLimpio = telefonoTexto.replaceAll("[^\\d]", "");
                    if (!telefonoLimpio.isEmpty()) {
                        lugar.setTelefono(Integer.parseInt(telefonoLimpio));
                    } else {
                        lugar.setTelefono(0);
                    }
                } catch (NumberFormatException e) {
                    Log.w("EdicionLugar", "Número de teléfono inválido: " + telefonoTexto);
                    lugar.setTelefono(0);
                    Toast.makeText(this, "Número de teléfono inválido, se guardará vacío", Toast.LENGTH_SHORT).show();
                }
            } else {
                lugar.setTelefono(0);
            }

            lugar.setUrl(url.getText().toString());
            lugar.setComentario(comentario.getText().toString());

            // Actualizar en la base de datos
            Lugares.actualizarLugar((int) id, lugar);

            // ESTABLECER RESULTADO OK
            setResult(Activity.RESULT_OK);

            Log.d("EdicionLugar", "Lugar guardado exitosamente - ID: " + id);
            Log.d("EdicionLugar", "Teléfono guardado: " + lugar.getTelefono());
            Toast.makeText(this, "Lugar guardado correctamente", Toast.LENGTH_SHORT).show();

            finish();

        } catch (Exception e) {
            Log.e("EdicionLugar", "Error al guardar lugar: " + e.getMessage(), e);
            Toast.makeText(this, "Error al guardar el lugar", Toast.LENGTH_LONG).show();
        }
    }

    public boolean onOptionsItemSelected(MenuItem item){
        int idItem = item.getItemId();
        Log.d("EdicionLugar", "Opción seleccionada: " + idItem);

        if (idItem == R.id.accion_cancelar){
            Log.d("EdicionLugar", "Cancelando - ID: " + id);
            if(getIntent().getExtras().getBoolean("nuevo",false)){
                Lugares.borrar((int) id);
            }
            setResult(Activity.RESULT_CANCELED);
            finish();
            return true;
        }
        if (idItem == R.id.accion_guardar){
            Log.d("EdicionLugar", "Guardando - ID: " + id);
            guardar();
            return true;
        }
        if (idItem == R.id.accion_geocodificar) {
            String direccionTexto = direccion.getText().toString().trim();
            if (!direccionTexto.isEmpty()) {
                geocodificarDireccion(direccionTexto);
            } else {
                Toast.makeText(this, "Ingresa una dirección primero", Toast.LENGTH_SHORT).show();
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        // Verificar si es un lugar nuevo y tiene datos incompletos
        Bundle extras = getIntent().getExtras();
        boolean esNuevo = extras != null && extras.getBoolean("nuevo", false);

        if (esNuevo && esLugarVacio()) {
            // Si es nuevo y está vacío, preguntar si quiere descartar
            new AlertDialog.Builder(this)
                    .setTitle("Descartar lugar")
                    .setMessage("El lugar no tiene datos. ¿Estás seguro de que quieres descartarlo?")
                    .setPositiveButton("Sí, descartar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // Borrar el lugar vacío y cerrar
                            Lugares.borrar((int) id);
                            setResult(Activity.RESULT_CANCELED);
                            finish();
                        }
                    })
                    .setNegativeButton("Seguir editando", null)
                    .show();
        } else if (esNuevo && !esLugarVacio()) {
            // Si es nuevo y tiene datos, preguntar si quiere guardar
            new AlertDialog.Builder(this)
                    .setTitle("Guardar cambios")
                    .setMessage("¿Quieres guardar los cambios antes de salir?")
                    .setPositiveButton("Guardar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            guardar();
                        }
                    })
                    .setNegativeButton("Descartar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // Borrar el lugar y cerrar
                            Lugares.borrar((int) id);
                            setResult(Activity.RESULT_CANCELED);
                            finish();
                        }
                    })
                    .setNeutralButton("Cancelar", null)
                    .show();
        } else {
            // Si es edición de lugar existente, comportamiento normal
            super.onBackPressed();
        }
    }

    // Método para verificar si el lugar está vacío
    private boolean esLugarVacio() {
        String nombreTexto = nombre.getText().toString().trim();
        String direccionTexto = direccion.getText().toString().trim();
        String telefonoTexto = telefono.getText().toString().trim();
        String urlTexto = url.getText().toString().trim();
        String comentarioTexto = comentario.getText().toString().trim();

        return nombreTexto.isEmpty() &&
                direccionTexto.isEmpty() &&
                telefonoTexto.isEmpty() &&
                urlTexto.isEmpty() &&
                comentarioTexto.isEmpty();
    }
}