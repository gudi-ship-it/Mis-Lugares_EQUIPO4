package com.example.mislugares10;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class Lugares {
    final static String TAG = "MisLugares";
    protected static GeoPunto posicionActual = new GeoPunto(0,0);
    // CAMBIO: Usar una lista de Lugar en lugar de un vector estático
    protected static List<Lugar> listaLugares = new ArrayList<>();
    private static Context context;

    // Método para inicializar el contexto
    public static void setContext(Context ctx) {
        context = ctx;
    }

    // MÉTODO NUEVO: Cargar lugares desde la base de datos
    public static void cargarLugaresDesdeBD() {
        listaLugares.clear();

        LugaresDB dbHelper = new LugaresDB(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM lugares", null);

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow("_id"));
            String nombre = cursor.getString(cursor.getColumnIndexOrThrow("nombre"));
            String direccion = cursor.getString(cursor.getColumnIndexOrThrow("direccion"));
            double longitud = cursor.getDouble(cursor.getColumnIndexOrThrow("longitud"));
            double latitud = cursor.getDouble(cursor.getColumnIndexOrThrow("latitud"));
            int tipo = cursor.getInt(cursor.getColumnIndexOrThrow("tipo"));
            String foto = cursor.getString(cursor.getColumnIndexOrThrow("foto"));
            int telefono = cursor.getInt(cursor.getColumnIndexOrThrow("telefono"));
            String url = cursor.getString(cursor.getColumnIndexOrThrow("url"));
            String comentario = cursor.getString(cursor.getColumnIndexOrThrow("comentario"));
            long fecha = cursor.getLong(cursor.getColumnIndexOrThrow("fecha"));
            float valoracion = cursor.getFloat(cursor.getColumnIndexOrThrow("valoracion"));

            // Usar el constructor con ID
            Lugar lugar = new Lugar(id, nombre, direccion, latitud, longitud,
                    TipoLugar.values()[tipo], telefono, url, comentario, (int)valoracion);
            lugar.setFoto(foto);
            lugar.setFecha(fecha);
            lugar.setValoracion(valoracion);

            listaLugares.add(lugar);
        }

        cursor.close();
        db.close();
    }

    // MÉTODO NUEVO: Obtener la lista de lugares
    public static List<Lugar> getListaLugares() {
        return new ArrayList<>(listaLugares);
    }

    public static Lugar elemento(int id){
        Log.d("Lugares", "Buscando elemento - ID: " + id);

        // Buscar en la lista
        for (Lugar lugar : listaLugares) {
            if (lugar.getId() == id) {
                return lugar;
            }
        }

        // Si no se encuentra en la lista, intentar cargar desde la BD
        // (esto no debería pasar si siempre cargamos la lista al inicio)
        LugaresDB dbHelper = new LugaresDB(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * from lugares WHERE _id = ?",
                new String[]{String.valueOf(id)});

        Lugar lugar = null;
        if(cursor.moveToNext()){
            Log.d("Lugares", "Elemento encontrado - ID: " + id);
            lugar = new Lugar();

            lugar.setId(id);
            lugar.setNombre(cursor.getString(cursor.getColumnIndexOrThrow("nombre")));
            lugar.setDireccion(cursor.getString(cursor.getColumnIndexOrThrow("direccion")));

            double longitud = cursor.getDouble(cursor.getColumnIndexOrThrow("longitud"));
            double latitud = cursor.getDouble(cursor.getColumnIndexOrThrow("latitud"));
            lugar.setPosicion(new GeoPunto(longitud, latitud));

            lugar.setTipo(TipoLugar.values()[cursor.getInt(cursor.getColumnIndexOrThrow("tipo"))]);
            lugar.setFoto(cursor.getString(cursor.getColumnIndexOrThrow("foto")));
            lugar.setTelefono(cursor.getInt(cursor.getColumnIndexOrThrow("telefono")));
            lugar.setUrl(cursor.getString(cursor.getColumnIndexOrThrow("url")));
            lugar.setComentario(cursor.getString(cursor.getColumnIndexOrThrow("comentario")));
            lugar.setFecha(cursor.getLong(cursor.getColumnIndexOrThrow("fecha")));
            lugar.setValoracion(cursor.getFloat(cursor.getColumnIndexOrThrow("valoracion")));

            // Añadir a la lista para futuras consultas
            listaLugares.add(lugar);
        } else {
            Log.e("Lugares", "Elemento NO encontrado - ID: " + id);
        }

        cursor.close();
        db.close();
        return lugar;
    }

    public static void actualizarLugar(int id, Lugar lugar){
        try {
            // Actualizar en la base de datos
            LugaresDB dbHelper = new LugaresDB(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues valores = new ContentValues();
            valores.put("nombre", lugar.getNombre());
            valores.put("direccion", lugar.getDireccion());
            valores.put("longitud", lugar.getPosicion().getLongitud());
            valores.put("latitud", lugar.getPosicion().getLatitud());
            valores.put("tipo", lugar.getTipo().ordinal());
            valores.put("foto", lugar.getFoto());
            valores.put("telefono", lugar.getTelefono());
            valores.put("url", lugar.getUrl());
            valores.put("comentario", lugar.getComentario());
            valores.put("fecha", lugar.getFecha());
            valores.put("valoracion", lugar.getValoracion());

            int filasAfectadas = db.update("lugares", valores, "_id = ?",
                    new String[]{String.valueOf(id)});

            db.close();

            if (filasAfectadas > 0) {
                Log.d("Lugares", "Lugar actualizado exitosamente - ID: " + id);
                // Actualizar en la lista
                for (int i = 0; i < listaLugares.size(); i++) {
                    if (listaLugares.get(i).getId() == id) {
                        listaLugares.set(i, lugar);
                        break;
                    }
                }
            } else {
                Log.e("Lugares", "No se pudo actualizar el lugar - ID: " + id);
            }
        } catch (Exception e) {
            Log.e("Lugares", "Error al actualizar lugar: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Este método ya no se usa, pero lo mantenemos por compatibilidad
    static void anyade(Lugar lugar){
        listaLugares.add(lugar);
    }

    public static int nuevo(){
        int id = -1;
        Lugar lugar = new Lugar();

        try {
            LugaresDB dbHelper = new LugaresDB(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues valores = new ContentValues();
            valores.put("longitud", lugar.getPosicion().getLongitud());
            valores.put("latitud", lugar.getPosicion().getLatitud());
            valores.put("tipo", lugar.getTipo().ordinal());
            valores.put("fecha", lugar.getFecha());

            // Insertar y obtener el ID
            long newRowId = db.insert("lugares", null, valores);

            if (newRowId != -1) {
                id = (int) newRowId;
                lugar.setId(id);
                listaLugares.add(lugar);
                Log.d("Lugares", "Nuevo lugar creado con ID: " + id);
            } else {
                Log.e("Lugares", "Error al crear nuevo lugar");
            }

            db.close();

        } catch (Exception e) {
            Log.e("Lugares", "Error en método nuevo(): " + e.getMessage());
        }

        return id;
    }

    public static void borrar(int id) {
        Log.d("Lugares", "Ejecutando borrado - ID: " + id);

        if (id < 0) {
            Log.e("Lugares", "ID inválido para borrar: " + id);
            return;
        }

        try {
            // Borrar de la base de datos
            LugaresDB dbHelper = new LugaresDB(context);
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            int filasAfectadas = db.delete("lugares", "_id = ?",
                    new String[]{String.valueOf(id)});
            db.close();

            Log.d("Lugares", "Filas afectadas al borrar: " + filasAfectadas);

            if (filasAfectadas > 0) {
                // Borrar de la lista
                for (int i = 0; i < listaLugares.size(); i++) {
                    if (listaLugares.get(i).getId() == id) {
                        listaLugares.remove(i);
                        break;
                    }
                }
                Log.d("Lugares", "Lugar borrado exitosamente - ID: " + id);
            } else {
                Log.e("Lugares", "No se encontró el lugar con ID: " + id);
            }
        } catch (Exception e) {
            Log.e("Lugares", "Error al borrar lugar: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static int size() {
        return listaLugares.size();
    }

    // Este método ya no se usa, pero lo mantenemos por compatibilidad
    public static ArrayList<Lugar> ejemploLugares(){
        ArrayList<Lugar> lugares = new ArrayList<Lugar>();
        // Nota: estos lugares no se guardan en la BD, solo en memoria
        lugares.add(new Lugar(1, "Escuela Politécnica Superior de Gandía",
                "C/ Paranimf, 1 46730 Gandia (SPAIN)", -0.166093, 38.995656,
                TipoLugar.EDUCACION, 962849300, "http://www.epsg.upv.es",
                "Uno de los mejores lugares para formarse.", 3));
        lugares.add(new Lugar(2, "El Chañar","Ruta Prov. 228",
                -64.5404009,-32.0672181,TipoLugar.RESTAURANTE,515273,
                "https://www.elchanar.com.ar","Un gran lugar para comer",3));
        // ... agregar los demás con IDs consecutivos
        return lugares;
    }

    public static void inicializaDB(Context contexto){
        context = contexto; // Guardar el contexto
        // Cargar los lugares desde la base de datos al inicializar
        cargarLugaresDesdeBD();
    }

    // Este método ya no se usa, pero lo mantenemos por compatibilidad
    public static Cursor listado(){
        LugaresDB dbHelper = new LugaresDB(context);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        return db.rawQuery("SELECT * FROM lugares",null);
    }

    // En la clase Lugares, mejorar el método buscarNombre:
    public static int buscarNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            return -1;
        }

        String nombreBusqueda = nombre.trim().toLowerCase();

        // Buscar coincidencia exacta primero
        for (Lugar lugar : listaLugares) {
            if (lugar.getNombre() != null &&
                    lugar.getNombre().toLowerCase().equals(nombreBusqueda)) {
                return (int) lugar.getId();
            }
        }

        // Si no hay coincidencia exacta, buscar parcial
        for (Lugar lugar : listaLugares) {
            if (lugar.getNombre() != null &&
                    lugar.getNombre().toLowerCase().contains(nombreBusqueda)) {
                return (int) lugar.getId();
            }
        }

        return -1;
    }

    public static int primerId(){
        if (listaLugares.isEmpty()) {
            return -1;
        }
        return (int) listaLugares.get(0).getId();
    }

    public static boolean existeLugar(int id) {
        for (Lugar lugar : listaLugares) {
            if (lugar.getId() == id) {
                return true;
            }
        }
        return false;
    }
}