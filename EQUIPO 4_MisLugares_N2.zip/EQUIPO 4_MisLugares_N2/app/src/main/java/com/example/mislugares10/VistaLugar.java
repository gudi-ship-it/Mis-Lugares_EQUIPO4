package com.example.mislugares10;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class VistaLugar extends AppCompatActivity {

    private long id;
    private Lugar lugar;
    private ImageView imageview;

    // CORREGIR: Usar códigos únicos
    final static int RESULTADO_EDITAR = 1234;  // Ya lo estás usando
    final static int RESULTADO_GALERIA = 1235;
    final static int RESULTADO_FOTO = 1236;

    private Uri uriFoto;

    @Override
    protected void onCreate(Bundle savedInstancestate) {
        super.onCreate(savedInstancestate);
        setContentView(R.layout.vista_lugar);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            id = extras.getLong("id", -1);

            // VERIFICAR MÁS DETALLADAMENTE
            if (id == -1) {
                Log.e("VistaLugar", "ID inválido recibido");
                Toast.makeText(this, "Error: ID inválido", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            // VERIFICAR SI EL LUGAR EXISTE EN LA BD
            if (!Lugares.existeLugar((int) id)) {
                Log.e("VistaLugar", "Lugar no existe en BD - ID: " + id);
                Toast.makeText(this, "Error: Lugar no encontrado", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

            lugar = Lugares.elemento((int) id);
            if (lugar == null) {
                Log.e("VistaLugar", "No se pudo cargar el lugar - ID: " + id);
                Toast.makeText(this, "Error al cargar el lugar", Toast.LENGTH_SHORT).show();
                finish();
                return;
            }

        } else {
            Log.e("VistaLugar", "No se recibieron extras");
            Toast.makeText(this, "Error: No se recibió ID", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        imageview = (ImageView) findViewById(R.id.foto);
        actualizarVistas();
    }

    public void actualizarVistas(){
        lugar = Lugares.elemento((int) id);
        TextView nombre = findViewById(R.id.nombre);
        nombre.setText(lugar.getNombre());
        ImageView logo_tipo = findViewById(R.id.logo_tipo);
        logo_tipo.setImageResource(lugar.getTipo().getRecurso());
        TextView tipo = findViewById(R.id.tipo);
        tipo.setText(lugar.getTipo().getTexto());
        TextView direccion = findViewById(R.id.direccion);
        direccion.setText(lugar.getDireccion());
        TextView telefono = findViewById(R.id.telefono);
        telefono.setText(Integer.toString(lugar.getTelefono()));
        TextView url = findViewById(R.id.url);
        url.setText(lugar.getUrl());
        TextView comentario = findViewById(R.id.comentario);
        comentario.setText(lugar.getComentario());
        TextView fecha = findViewById(R.id.fecha);
        fecha.setText(DateFormat.getDateInstance().format(
                new Date(lugar.getFecha())));
        TextView hora = findViewById(R.id.hora);
        hora.setText(DateFormat.getTimeInstance().format(
                new Date(lugar.getFecha())));
        RatingBar valoracion = findViewById(R.id.valoracion);
        valoracion.setRating(lugar.getValoracion());
        valoracion.setOnRatingBarChangeListener(
                new RatingBar.OnRatingBarChangeListener() {
                    @Override
                    public void onRatingChanged(RatingBar ratingBar,
                                                float valor, boolean fromUser) {
                        lugar.setValoracion(valor);
                        Lugares.actualizarLugar((int) id, lugar);
                    }
                }
        );
        ponerFoto(imageview, lugar.getFoto());
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_vista_lugar, menu);
        return true;
    }

    public void lanzarBorrar() {
        Log.d("VistaLugar", "Iniciando borrado - ID: " + id);

        new AlertDialog.Builder(this)
                .setTitle("Borrado de lugar")
                .setMessage("¿Estás seguro de querer eliminar este lugar?")
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int cualBoton) {
                        Log.d("VistaLugar", "Confirmado borrado - ID: " + id);
                        if (id >= 0) {
                            Lugares.borrar((int) id);

                            // ESTABLECER RESULTADO PARA QUE MAINACTIVITY SEPA QUE SE BORRÓ UN LUGAR
                            setResult(Activity.RESULT_OK);

                            Toast.makeText(VistaLugar.this, "Lugar eliminado correctamente", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            Log.e("VistaLugar", "ID inválido: " + id);
                            Toast.makeText(VistaLugar.this, "ID inválido", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    public void lanzarEditarLugar(){
        Intent i = new Intent(VistaLugar.this, EdicionLugar.class);
        i.putExtra("id", id);
        startActivityForResult(i, 1234);
    }

    @SuppressLint("MissingSuperCall")
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d("VistaLugar", "onActivityResult - request: " + requestCode + ", result: " + resultCode);

        if (resultCode == Activity.RESULT_OK) {
            switch (requestCode) {
                case RESULTADO_EDITAR:
                    // Recargar datos después de editar
                    actualizarVistas();
                    Log.d("VistaLugar", "Edición completada - vistas actualizadas");

                    // NOTIFICAR A MAINACTIVITY QUE HAY CAMBIOS
                    setResult(Activity.RESULT_OK);
                    break;

                case RESULTADO_FOTO:
                    // Para foto de cámara
                    Log.d("VistaLugar", "Foto tomada exitosamente - URI: " + uriFoto);

                    if (lugar != null && uriFoto != null) {
                        try {
                            // Guardar la URI en la base de datos
                            lugar.setFoto(uriFoto.toString());
                            Lugares.actualizarLugar((int) id, lugar);

                            // Actualizar la imagen inmediatamente
                            ponerFoto(imageview, lugar.getFoto());

                            Toast.makeText(this, "Foto guardada correctamente", Toast.LENGTH_SHORT).show();
                            Log.d("VistaLugar", "Foto guardada en la base de datos: " + uriFoto.toString());
                        } catch (Exception e) {
                            Log.e("VistaLugar", "Error al guardar foto: " + e.getMessage());
                            Toast.makeText(this, "Error al guardar la foto", Toast.LENGTH_LONG).show();
                        }
                    }
                    break;

                case RESULTADO_GALERIA:
                    // Para galería
                    if (data != null && data.getData() != null) {
                        Uri imagenUri = data.getData();
                        Log.d("VistaLugar", "Imagen seleccionada de galería - URI: " + imagenUri);

                        if (lugar != null) {
                            try {
                                // Obtener permisos persistentes
                                final int takeFlags = data.getFlags() &
                                        (Intent.FLAG_GRANT_READ_URI_PERMISSION |
                                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                                getContentResolver().takePersistableUriPermission(imagenUri, takeFlags);

                                // Guardar la URI
                                lugar.setFoto(imagenUri.toString());
                                Lugares.actualizarLugar((int) id, lugar);

                                // Actualizar la imagen inmediatamente
                                ponerFoto(imageview, lugar.getFoto());

                                Toast.makeText(this, "Imagen seleccionada correctamente", Toast.LENGTH_SHORT).show();
                                Log.d("VistaLugar", "Imagen de galería guardada: " + imagenUri.toString());
                            } catch (Exception e) {
                                Log.e("VistaLugar", "Error al procesar imagen de galería: " + e.getMessage());
                                Toast.makeText(this, "Error al procesar la imagen", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                    break;
            }
        } else if (resultCode == Activity.RESULT_CANCELED) {
            Log.d("VistaLugar", "Usuario canceló la operación para request: " + requestCode);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int idItem = item.getItemId();

        if (idItem == R.id.accion_compartir) {
            mostrarDialogoBuscarLugarParaCompartir();
            return true;

        } else if (idItem == R.id.accion_llegar) {
            mostrarDialogoBuscarLugarParaMapa();
            return true;

        } else if (idItem == R.id.accion_borrar) {
            lanzarBorrar();
            return true;

        } else if (idItem == R.id.accion_editar) {
            lanzarEditarLugar();
            return true;

        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    // NUEVO MÉTODO: Diálogo para buscar lugar para compartir
    private void mostrarDialogoBuscarLugarParaCompartir() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Compartir Lugar");

        final View dialogView = getLayoutInflater().inflate(R.layout.dialogo_buscar_lugar, null);
        builder.setView(dialogView);

        final EditText etId = dialogView.findViewById(R.id.etId);
        final EditText etNombre = dialogView.findViewById(R.id.etNombre);

        builder.setPositiveButton("Compartir", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idTexto = etId.getText().toString().trim();
                String nombre = etNombre.getText().toString().trim();

                long idCompartir = -1;

                if (!idTexto.isEmpty()) {
                    try {
                        idCompartir = Long.parseLong(idTexto);
                    } catch (NumberFormatException e) {
                        Toast.makeText(VistaLugar.this, "ID debe ser un número válido", Toast.LENGTH_LONG).show();
                        return;
                    }
                } else if (!nombre.isEmpty()) {
                    idCompartir = Lugares.buscarNombre(nombre);
                    if (idCompartir == -1) {
                        Toast.makeText(VistaLugar.this, "No se encontró lugar con nombre: " + nombre, Toast.LENGTH_LONG).show();
                        return;
                    }
                } else {
                    Toast.makeText(VistaLugar.this, "Ingresa ID o nombre del lugar", Toast.LENGTH_LONG).show();
                    return;
                }

                if (!Lugares.existeLugar((int) idCompartir)) {
                    Toast.makeText(VistaLugar.this, "No existe el lugar con ID: " + idCompartir, Toast.LENGTH_LONG).show();
                    return;
                }

                compartirLugar(Lugares.elemento((int) idCompartir));
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    // NUEVO MÉTODO: Diálogo para buscar lugar para mapa
    private void mostrarDialogoBuscarLugarParaMapa() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Cómo Llegar");

        final View dialogView = getLayoutInflater().inflate(R.layout.dialogo_buscar_lugar, null);
        builder.setView(dialogView);

        final EditText etId = dialogView.findViewById(R.id.etId);
        final EditText etNombre = dialogView.findViewById(R.id.etNombre);

        builder.setPositiveButton("Obtener Indicaciones", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String idTexto = etId.getText().toString().trim();
                String nombre = etNombre.getText().toString().trim();

                long idDestino = -1;

                if (!idTexto.isEmpty()) {
                    try {
                        idDestino = Long.parseLong(idTexto);
                    } catch (NumberFormatException e) {
                        Toast.makeText(VistaLugar.this, "ID debe ser un número válido", Toast.LENGTH_LONG).show();
                        return;
                    }
                } else if (!nombre.isEmpty()) {
                    idDestino = Lugares.buscarNombre(nombre);
                    if (idDestino == -1) {
                        Toast.makeText(VistaLugar.this, "No se encontró lugar con nombre: " + nombre, Toast.LENGTH_LONG).show();
                        return;
                    }
                } else {
                    Toast.makeText(VistaLugar.this, "Ingresa ID o nombre del lugar", Toast.LENGTH_LONG).show();
                    return;
                }

                if (!Lugares.existeLugar((int) idDestino)) {
                    Toast.makeText(VistaLugar.this, "No existe el lugar con ID: " + idDestino, Toast.LENGTH_LONG).show();
                    return;
                }

                obtenerIndicacionesHaciaLugar(idDestino);
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    // Método para compartir la información del lugar
    private void compartirLugar(Lugar lugarCompartir) {
        StringBuilder textoCompartir = new StringBuilder();
        textoCompartir.append("🌟 ").append(lugarCompartir.getNombre()).append("\n\n");

        if (lugarCompartir.getDireccion() != null && !lugarCompartir.getDireccion().isEmpty()) {
            textoCompartir.append("📍 Dirección: ").append(lugarCompartir.getDireccion()).append("\n");
        }

        if (lugarCompartir.getPosicion() != null &&
                lugarCompartir.getPosicion().getLatitud() != 0 &&
                lugarCompartir.getPosicion().getLongitud() != 0) {

            double lat = lugarCompartir.getPosicion().getLatitud();
            double lon = lugarCompartir.getPosicion().getLongitud();
            textoCompartir.append("🗺️ Ubicación: ").append(lat).append(", ").append(lon).append("\n");

            // Agregar enlace a Google Maps
            textoCompartir.append("https://maps.google.com/?q=").append(lat).append(",").append(lon).append("\n");
        }

        if (lugarCompartir.getTelefono() != 0) {
            textoCompartir.append("📞 Teléfono: ").append(lugarCompartir.getTelefono()).append("\n");
        }

        if (lugarCompartir.getUrl() != null && !lugarCompartir.getUrl().isEmpty()) {
            textoCompartir.append("🌐 Web: ").append(lugarCompartir.getUrl()).append("\n");
        }

        if (lugarCompartir.getComentario() != null && !lugarCompartir.getComentario().isEmpty()) {
            textoCompartir.append("📝 Comentario: ").append(lugarCompartir.getComentario()).append("\n");
        }

        textoCompartir.append("\nCompartido desde Mis Lugares App");

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Lugar recomendado: " + lugarCompartir.getNombre());
        intent.putExtra(Intent.EXTRA_TEXT, textoCompartir.toString());

        startActivity(Intent.createChooser(intent, "Compartir lugar"));
    }

    public void verMapa(View view){
        mostrarDialogoBuscarLugarParaMapa();
    }

    // NUEVO MÉTODO: Obtener indicaciones hacia un lugar específico
    // En VistaLugar.java, reemplaza el método obtenerIndicacionesHaciaLugar por este:

    private void obtenerIndicacionesHaciaLugar(long idDestino) {
        Lugar lugarDestino = Lugares.elemento((int) idDestino);

        if (lugarDestino == null) {
            Toast.makeText(this,
                    "Error: No existe un lugar con ID " + idDestino,
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (lugarDestino.getPosicion() == null ||
                lugarDestino.getPosicion().getLatitud() == 0 ||
                lugarDestino.getPosicion().getLongitud() == 0) {
            Toast.makeText(this,
                    "Este lugar no tiene coordenadas definidas",
                    Toast.LENGTH_LONG).show();
            return;
        }

        double latDestino = lugarDestino.getPosicion().getLatitud();
        double lonDestino = lugarDestino.getPosicion().getLongitud();
        String nombre = lugarDestino.getNombre();

        // Crear URI para Google Maps en modo visualización normal
        Uri gmmIntentUri = Uri.parse("geo:" + latDestino + "," + lonDestino + "?z=15&q=" + latDestino + "," + lonDestino + "(" + Uri.encode(nombre) + ")");

        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        // Verificar si Google Maps está disponible
        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            // Alternativa: usar la URL web de Google Maps
            Uri webIntentUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + latDestino + "," + lonDestino + "&query_place_id=" + Uri.encode(nombre));
            Intent webIntent = new Intent(Intent.ACTION_VIEW, webIntentUri);

            if (webIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(webIntent);
            } else {
                Toast.makeText(this,
                        "No hay aplicaciones de mapas instaladas",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    // Este método ya existe en tu código, lo mantenemos igual
    private void abrirMapaConDestino(Lugar lugarDestino) {
        double lat = lugarDestino.getPosicion().getLatitud();
        double lon = lugarDestino.getPosicion().getLongitud();
        String nombre = lugarDestino.getNombre();

        if (lat == 0 && lon == 0) {
            Toast.makeText(this,
                    "Este lugar no tiene coordenadas definidas",
                    Toast.LENGTH_LONG).show();
            return;
        }

        // Crear URI para Google Maps
        Uri gmmIntentUri = Uri.parse("geo:" + lat + "," + lon + "?z=15&q=" + lat + "," + lon + "(" + Uri.encode(nombre) + ")");

        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        // Verificar si Google Maps está disponible
        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            // Intentar con cualquier aplicación de mapas
            Intent fallbackIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("geo:" + lat + "," + lon + "?q=" + lat + "," + lon));

            if (fallbackIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(fallbackIntent);
            } else {
                Toast.makeText(this,
                        "No hay aplicaciones de mapas instaladas",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    public void llamadaTelefono(View view){
        startActivity(new Intent(Intent.ACTION_DIAL,
                Uri.parse("tel:" + lugar.getTelefono())));
    }

    public void paginaWeb(View view){
        startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse(lugar.getUrl())));
    }

    public void galeria(View view){
        try {
            // USAR ACTION_PICK en lugar de ACTION_GET_CONTENT para mejor compatibilidad
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");

            // Verificar que hay una app para manejar la galería
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(Intent.createChooser(intent, "Seleccionar imagen"), RESULTADO_GALERIA);
            } else {
                // Si no hay app de galería, intentar con ACTION_GET_CONTENT
                Intent intentAlternativo = new Intent(Intent.ACTION_GET_CONTENT);
                intentAlternativo.setType("image/*");
                intentAlternativo.addCategory(Intent.CATEGORY_OPENABLE);

                if (intentAlternativo.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(Intent.createChooser(intentAlternativo, "Seleccionar imagen"), RESULTADO_GALERIA);
                } else {
                    Toast.makeText(this, "No hay app de galería disponible", Toast.LENGTH_LONG).show();
                }
            }
        } catch (Exception e) {
            Log.e("VistaLugar", "Error al abrir galería: " + e.getMessage());
            Toast.makeText(this, "Error al acceder a la galería: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    protected void ponerFoto(ImageView imageview, String uri){
        if (uri != null && !uri.isEmpty()) {
            try {
                Log.d("VistaLugar", "Intentando cargar imagen: " + uri);

                // Para URIs de contenido (galería) y archivos (cámara)
                Bitmap bitmap = null;

                if (uri.startsWith("content://") || uri.startsWith("file://")) {
                    bitmap = reduceBitmap(this, uri, 1024, 1024);
                } else {
                    // Intentar como ruta de archivo directa
                    File archivo = new File(uri);
                    if (archivo.exists()) {
                        bitmap = reduceBitmap(this, Uri.fromFile(archivo).toString(), 1024, 1024);
                    }
                }

                if (bitmap != null) {
                    imageview.setImageBitmap(bitmap);
                    Log.d("VistaLugar", "Imagen cargada exitosamente");
                } else {
                    // Si no se puede cargar, limpiar la imagen
                    imageview.setImageDrawable(null);
                    Log.e("VistaLugar", "No se pudo cargar la imagen");
                }
            } catch (Exception e) {
                imageview.setImageDrawable(null);
                Log.e("VistaLugar", "Error al cargar imagen: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            // No hay imagen - limpiar ImageView
            imageview.setImageDrawable(null);
            Log.d("VistaLugar", "No hay imagen para mostrar, ImageView limpiado");
        }
    }

    public void tomarFoto(View view) {
        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

            // Verificar que hay una cámara disponible
            if (intent.resolveActivity(getPackageManager()) == null) {
                Toast.makeText(this, "No hay aplicación de cámara disponible", Toast.LENGTH_LONG).show();
                return;
            }

            // Crear archivo con nombre único
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
            String imageFileName = "JPEG_" + timeStamp + "_";

            File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            File imageFile = File.createTempFile(
                    imageFileName,  /* prefix */
                    ".jpg",         /* suffix */
                    storageDir      /* directory */
            );

            // Guardar la ruta del archivo para uso posterior
            String currentPhotoPath = imageFile.getAbsolutePath();

            // Obtener URI usando FileProvider
            uriFoto = FileProvider.getUriForFile(this,
                    getApplicationContext().getPackageName() + ".provider",
                    imageFile);

            Log.d("VistaLugar", "Ruta de foto: " + currentPhotoPath);
            Log.d("VistaLugar", "URI de foto: " + uriFoto.toString());

            // Configurar intent
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uriFoto);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

            // Iniciar actividad de cámara
            startActivityForResult(intent, RESULTADO_FOTO);

        } catch (IOException e) {
            Log.e("VistaLugar", "Error al crear archivo de imagen: " + e.getMessage());
            Toast.makeText(this, "Error al crear archivo de imagen", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e("VistaLugar", "Error inesperado en tomarFoto: " + e.getMessage());
            Toast.makeText(this, "Error al acceder a la cámara", Toast.LENGTH_LONG).show();
        }
    }

    // Método para mostrar alternativas cuando no hay cámara
    private void mostrarAlternativasCamara() {
        new AlertDialog.Builder(this)
                .setTitle("Cámara no disponible")
                .setMessage("No se encontró una aplicación de cámara en tu dispositivo. ¿Qué te gustaría hacer?")
                .setPositiveButton("Usar Galería", (dialog, which) -> {
                    galeria(null);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    public void eliminarFoto(View view){
        new AlertDialog.Builder(this)
                .setTitle("Eliminación de foto")
                .setMessage("¿Estás seguro de que quieres eliminar la foto?")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int cualBoton) {
                        // Limpiar la referencia de la foto
                        lugar.setFoto(null);
                        Lugares.actualizarLugar((int) id, lugar);

                        // CORRECCIÓN: Establecer ImageView a null o imagen vacía
                        imageview.setImageDrawable(null); // Esto elimina cualquier imagen
                        // O alternativamente, establecer un drawable transparente:
                        // imageview.setImageResource(android.R.color.transparent);

                        // También puedes ocultar el ImageView si lo prefieres:
                        // imageview.setVisibility(View.GONE);

                        Toast.makeText(VistaLugar.this, "Foto eliminada", Toast.LENGTH_SHORT).show();
                        Log.d("VistaLugar", "Foto eliminada del lugar ID: " + id);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    public static Bitmap reduceBitmap(Context contexto, String uri,
                                      int MaxAncho, int MaxAlto){
        try{
            final BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(contexto.getContentResolver()
                    .openInputStream(Uri.parse(uri)),null,options);
            options.inSampleSize = (int) Math.max(
                    Math.ceil(options.outWidth / MaxAncho),
                    Math.ceil(options.outHeight / MaxAlto));
            options.inJustDecodeBounds = false;
            return BitmapFactory.decodeStream(contexto.getContentResolver()
                    .openInputStream(Uri.parse(uri)),null,options);
        }
        catch (FileNotFoundException e){
            Toast.makeText(contexto,"File Not Found",
                    Toast.LENGTH_LONG).show();
            e.printStackTrace();
            return null;
        }
    }


    public void cambiarFecha(View view) {
        if (lugar == null) return;

        Calendar calendario = Calendar.getInstance();
        calendario.setTimeInMillis(lugar.getFecha());

        DatePickerDialog dialogoFecha = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker vista, int anyo, int mes, int dia) {
                        // Mantener la hora actual y cambiar solo la fecha
                        Calendar nuevaFecha = Calendar.getInstance();
                        nuevaFecha.setTimeInMillis(lugar.getFecha());
                        nuevaFecha.set(Calendar.YEAR, anyo);
                        nuevaFecha.set(Calendar.MONTH, mes);
                        nuevaFecha.set(Calendar.DAY_OF_MONTH, dia);

                        lugar.setFecha(nuevaFecha.getTimeInMillis());
                        Lugares.actualizarLugar((int) id, lugar);
                        actualizarVistas();

                        Toast.makeText(VistaLugar.this, "Fecha actualizada", Toast.LENGTH_SHORT).show();
                    }
                },
                calendario.get(Calendar.YEAR),
                calendario.get(Calendar.MONTH),
                calendario.get(Calendar.DAY_OF_MONTH)
        );
        dialogoFecha.show();
    }

    public void cambiarHora(View view) {
        if (lugar == null) return;

        Calendar calendario = Calendar.getInstance();
        calendario.setTimeInMillis(lugar.getFecha());

        TimePickerDialog dialogoHora = new TimePickerDialog(
                this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker vista, int hora, int minuto) {
                        // Mantener la fecha actual y cambiar solo la hora
                        Calendar nuevaHora = Calendar.getInstance();
                        nuevaHora.setTimeInMillis(lugar.getFecha());
                        nuevaHora.set(Calendar.HOUR_OF_DAY, hora);
                        nuevaHora.set(Calendar.MINUTE, minuto);

                        lugar.setFecha(nuevaHora.getTimeInMillis());
                        Lugares.actualizarLugar((int) id, lugar);
                        actualizarVistas();

                        Toast.makeText(VistaLugar.this, "Hora actualizada", Toast.LENGTH_SHORT).show();
                    }
                },
                calendario.get(Calendar.HOUR_OF_DAY),
                calendario.get(Calendar.MINUTE),
                android.text.format.DateFormat.is24HourFormat(this) // ← CORREGIDO
        );
        dialogoHora.show();
    }
}